/*
    Aggregation file for all different styles...
    Reference this single file in views instead of individual files
    Individual files are only for code clarity
*/
import * as ContainerStyles from "./containers";
import * as ImageStyles from "./images";
import * as Typography from "./typography"
import * as Spacing from "./spacing";
import * as Colors from "./colors";

export {ContainerStyles,ImageStyles,Typography,Spacing, Colors}