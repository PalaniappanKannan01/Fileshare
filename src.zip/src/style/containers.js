/*
    Holds all styles and style values for container objects
*/
import * as Colors from "./colors";
export const pageContainer = {
    flex:1,
    paddingTop: Platform.OS === 'ios' ? 42 : 0,
    width:"100%",
    height:"100%",
    backgroundColor:"white"
};

export const pageCenterHorz = {
    flex:1,
    justifyContent:"center",
    alignItems:"flex-start"
};
export const absPageCenter={
    ...pageCenterHorz,
    alignItems:"center"
};

export const input =  {
    margin: 15,
    height: 48,
    borderColor: Colors.darkGray,
    borderWidth: 1,
    borderRadius: 10,
    paddingLeft: 16,  
    marginBottom: 10,
 };

 export const textBoxContainer = {
    position: 'relative',
    alignSelf: 'stretch',
    justifyContent: 'center'
 };

 export const touachableButton = {
    position: 'absolute',
    right: 25,
    padding: 2,
 };
 export const buttonPass = {
    fontSize: 16,
    color: Colors.vinyaDefaultColor,
    fontWeight: 'bold'
 }
 export const adlChartsHeader = {
    width:"100%",  
    flexDirection:"row", 
    alignItems:"center", 
    justifyContent:"space-between"
 };

 export const bottomShadow ={
    shadowColor:"#000000",
    shadowOffset:{width:0,height:4},
    shadowOpacity:0.22,
    shadowRadius:3,
    elevation:3
 };

 export const activitySummaryButton = {
    backgroundColor:"white",
    borderWidth:0,
    borderColor:"black",
    borderRadius:12,
    shadowColor:"black",
    shadowOffset:{width:0,height:1},
    shadowOpacity:0.22,
    shadowRadius:2,
    elevation:2,
    width:148,
    height:148,
    margin:12
};

export const activityStatusIcon = {
    width:32,
    height:32, 
    margin:4, 
    paddingLeft:240
};

export const activityIcon = {
    width:64,
    height:64,
    marginLeft:48
};