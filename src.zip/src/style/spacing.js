/*
    Holds all styles and style values for spacing definitions
*/
export const defaultLeftPad = {
    paddingLeft: 18
};

export const defaultPad = {
    padding: 2
};

export const largePad = {
    padding: 12
};

export const extraLargePad = {
    padding: 18
};
export const superLargePad = {
    padding: 48
};
export const defaultTopMargin = {
    marginTop: 8    
};

export const largeTopMargin = {
    marginTop: 16
};

export const extraLargeTopMargin = {
    marginTop: 32
};

export const superLargeTopMargin = {
    marginTop: 48
};