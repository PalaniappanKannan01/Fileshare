/*
    Holds all styles and style values for image objects
*/
import * as Colors from "./colors";

export const vidaLogo = {
    width:64,
    height:64,
    margin:0,
    padding:0
};

export const bigIcon = {
    width: 96,
    height:96,
    margin:0,
    padding:0
};

export const profileAvatar = {
    width: 72,
    height: 72,
    borderRadius: 50,
    borderColor: Colors.vinyaDefaultColor,
    borderWidth: 0,
    margin:6
};
export const profileAvatarNoBorder = {
    width: 72,
    height: 72,
    borderRadius: 50,
    borderWidth: 0,
    margin:6
};