/*
    Holds all styles and style values for text objects
*/
import {PixelRatio} from "react-native";
import * as Colors from "./colors";

export const boldBodyText = {
    fontWeight:"bold"
};

export const tabItemText = {
    fontSize: PixelRatio.get() < 2 ? 12 : 14,
};

export const H1 = {
    fontSize: PixelRatio.get() < 2 ? 18 : 24,
    fontWeight:"bold",
};

export const H3 = {
    fontSize: PixelRatio.get() < 2 ? 14 : 20,
    fontWeight:"bold",
};

export const anchor = {
    color : Colors.vinyaDefaultColor
};

export const label = {
    fontSize: 14,
    color: Colors.darkGray,
    textTransform: 'uppercase',
    paddingLeft: 20,
    fontWeight: 'normal',
};

export const adlName = {
    fontSize: 14,
    color: Colors.black,
    fontWeight: 'bold',
};

export const adlInfo = {
    fontSize: 12,
    color: Colors.darkGray,
};

export const validationTxt = {
    fontSize: 14,
    color: 'red',
    paddingLeft: 15,
 };