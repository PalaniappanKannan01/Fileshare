/**
 * Holds various colors that we will use
 */
export const black = "#000000";
export const darkestGray = "#29292c";
export const darkGray = "#3d3e44";
export const defaultPurple = "#9775fa";
export const mediumGray = "#868e96";
export const superLightGray = "#EDEDED";
export const lightGray = "#bababa";
export const lightWarmGray = "#f5f5f5";
export const offWhite = "#b7bdc5";
export const tan = "#fcf8f2";
export const teal= "#3bc9db";
export const orange="#ff922b";
export const darkNavyBlue = "#0c3256";
export const blue = "#4CB1F7";
export const green="#3D7300";
export const appRed = "#fa5252";
export const yellow = "#FFEC00";
export const transparent = "rgba(0, 0, 0, 0)";
export const white = "#ffffff";

export const baseText = darkGray;
export const darkText = darkestGray;
export const sectionBackground = lightWarmGray;
export const background = white;
export const vinyaDefaultColor = defaultPurple;
export const vinyaDefaultColorAsRGB='rgb(134, 65, 244)';
export const selected = appRed;
export const unselected = lightGray;

export const testSpotColor = {
  backgroundColor: "bisque",
};
