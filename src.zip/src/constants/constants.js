export const MAX_PWD_LENGTH = 8;
export const HELPDESK_PHONE = "888-HLP-VIDA";
export const HELPDESK_EMAIL = "care@vinya.com";
export const TNC_URL = "https://www.vinya.com/terms-of-use";
export const PP_URL = "https://www.vinya.com/privacy-policy"; 
export const MISSING_DATA_INFO_URL="https://www.vinya.com/missingdata";
export const BASE_API_URL = "https://api.vinyaservices.com/vida";

export const START_END_TIME="12:00:00" //all 24 hour data will be blocked between yesterday 12PM to today 12PM
export const ActivityDataFilters = { day : "day" , week : "week" , month : "month", year:"year" };
