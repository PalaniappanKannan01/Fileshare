import { AuthApi } from "./auth";
import * as Constants from "../constants/constants";
import { call } from "react-native-reanimated";
import { DateUtils } from "../utils/dateutils";
import AsyncStorage from '@react-native-community/async-storage';

/*All endpoints related to ADL */
export const AdlApi = {
  
  /**
   * Get the summary of the current logged in user.
   * This allows us to paint the "My Activity" screen.
   */
  getUserSummary: async (callback) => {
    AuthApi.getJwtToken().then((token) => {
      if (token != null) {
        var fetchOptions = {
          method: "GET",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization:  token,
          },
        };

        fetch(Constants.BASE_API_URL + "/summary", fetchOptions)
          .then((resp) => {
            return resp.json();
          })
          .then((json) => {
            callback(json, null);
          })
          .catch((err) => {
            callback(null, err);
          });
      }
    });
  },
  loadUserAvatarFromLocal : async()=>{
    try{
      const avatar = await AsyncStorage.getItem("__VINYA_VIDA_USER_AVATAR");
      return avatar; 
    }catch(e){
      console.log(e);
    }
  },
  saveUserAvatarToLocal : async(av)=>{
    try{
      const avatar = await AsyncStorage.setItem("__VINYA_VIDA_USER_AVATAR", av);
    }catch(e){
      console.log(e);
    }
  },
  updateName : async(newName) =>{
    let token = await AuthApi.getJwtToken();
    if (token != null) {
      var fetchOptions = {
        method: "POST",
        headers: {
          Authorization: 'Bearer ' + token,
        },
      };
      
      return fetch(Constants.BASE_API_URL + "/profile?name=" + encodeURIComponent(newName), fetchOptions);
    }
  },
  /*Get user's profile picture */
  getUserAvatar : async (email) =>{
    let token = await AuthApi.getJwtToken();
    //console.log("getUserAvatar Token=" + token);
    if (token != null) {
      //console.log("token received=" + token);
      var fetchOptions = {
        method: "GET",
        headers: {
          Authorization: 'Bearer ' + token,
        },
      };
      //let qs = encodeURIComponent(email);
      return fetch(Constants.BASE_API_URL + "/images/" + email, fetchOptions);
    }
  },
  /*Get given user's activity related information*/
  getActivityData : async(id, activity, range, offset, callback) =>{
    AuthApi.getJwtToken().then((token) => {
      console.log("Got Jwt token...");
      if (token != null) {
        console.log("preparing fetch");
        var fetchOptions = {
          method: "GET",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: token,
          },
        };
        //let qdate = DateUtils.toApiDate(since);
        //sample url is .../residents/98sueooye/sleep/[day,week,month,year]?start=YYYY-mm-dd
        let url = Constants.BASE_API_URL + "/residents/" + id + "/" + activity + "/" + range + "?offset=" + offset;
        console.log("URL to call.." + url);
        fetch(url , fetchOptions)
          .then((resp) => {
            return resp.json();
          })
          .then((json) => {
            callback(json, null);
          })
          .catch((err) => {
            callback(null, err);
          });
      }
    });
  }
};
