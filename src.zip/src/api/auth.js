import Amplify, { Auth } from "aws-amplify";
import awsconfig from "../../aws-exports";

Amplify.configure({
  ...awsconfig,
  Analytics: {
    disabled: true,
  },
});

export const AuthApi = {
  getJwtToken: async () => {
    const result = await Auth.currentAuthenticatedUser();
    if (result != null && typeof result !== "undefined")
      return result["signInUserSession"]["idToken"]["jwtToken"];
    else return null;
  },
  isLoggedIn: async () => {
    let result = false;
    try {
      let authUser = await Auth.currentAuthenticatedUser();
      console.log("AuthApi.isLoggedIn...authUser=" + authUser);
      result = authUser != null && typeof authUser !== "undefined";
    } catch (err) {
      console.log("Failed to get current authenticated user..." + err);
    }
    return result;
  },
  login: async (u, p) => {
    return await Auth.signIn(u, p);
  },
  logout: async () => {
    return Auth.signOut({global:true});
  },
  signUp: async (em, pw, nm) => {
    console.log("Into AuthApi.signUp..." + em + "," + nm);
    try {
      const { user } = await Auth.signUp({
        username: em, //using email as username
        password: pw,
        attributes: {
          email: em, //fixit..need to add custom attribute 'name' for user
          "custom:name": nm,
        },
      });
      return user;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
};
