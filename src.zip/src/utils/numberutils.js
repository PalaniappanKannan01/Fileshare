export const NumberUtils = {
    findMin : (arr) =>{
        let min = Number.MAX_SAFE_INTEGER;
        for(let i=0; i < arr.length; i++) {
            let elm = arr[i];
            if(elm != null) 
                if(elm < min) min = elm;
        }
        return min;
    },
    findMax : (arr) =>{
        let max = Number.MIN_SAFE_INTEGER;
        for(let i=0; i < arr.length; i++) {
            let elm = arr[i];
            if(elm != null) 
                if(elm > max) max = elm;
        }
        return max;
    }
};