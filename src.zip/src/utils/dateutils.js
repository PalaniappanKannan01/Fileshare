import * as StringUtils from "./stringutils";

export const DateUtils = {
    getMonthName : (m)=>{
        let names=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
        return names[m];
    },
    toApiDate : (d) =>{
        //return the date object in API date format YYYY-MM-dd
        let apid = d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate();
        return apid;
    },
    todayForApi : ()=>{
        //vinya api takes date in YYYY-MM-dd format
        let now = new Date();
        let str = now.getFullYear() + "-" + (now.getMonth()+1) + "-" + now.getDate();
        return str;
    },
    extractTimezone : (dstr)=>{
        if(dstr.indexOf("+") > 0)
            offset = dstr.substring(dstr.indexOf("+"));
        else
            offset = dstr.substring(dstr.lastIndexOf("-"));
        return offset;
    },
    apiDateToJSDate : (d)=>{
        return new Date(Date.parse(d));
    },
    todayAsString : () =>{
        let now = new Date();
        let str = now.getDate() + "-" + DateUtils.getMonthName(now.getMonth()) + "-" + now.getFullYear();
        return str;
    },
    reformat_1 : (d)=>{
        /*We take YYYY-mm-dd and convert to dd MMM YYYY */
        let parts = d.split("-");
        let newFormat = parts[2] + " " + DateUtils.getMonthName( parseInt(parts[1]-1,10) ) + " " + part[0];
        
        return newFormat;
    },
    addDays : (d,a)=>{
        let nd = new Date(d.getTime());
        nd.setDate(nd.getDate()+a);
        return nd;
    },
    findMin : (arr) =>{
        /*It is assumed that array contains date in Javascript parsable format */
        let mindt = new Date(9999,12,31);
        for(let i=0; i < arr.length; i++) {
            let elm = arr[i];
            if(elm != null) {
                let dt = new Date( Date.parse(elm) );
                if(dt < mindt) mindt = dt;
            }
        }
        return mindt;
    },
    findMax : (arr) =>{
        /*It is assumed that array contains date in Javascript parsable format */
        let maxdt = new Date(1970,1,1);
        for(let i=0; i < arr.length; i++) {
            let elm = arr[i];
            if(elm != null) {
                let dt = new Date( Date.parse(elm) );
                if(dt > maxdt) maxdt = dt;
            }
        }
        return maxdt;
    },
    prettyDuration : (duration) =>{
        let text = "";
        if(Math.floor(duration.d) == 1)
            text = Math.ceil(duration.d) + " day";
        else if(Math.floor(duration.d) > 1)
            text = Math.ceil(duration.d) + " days";

        if(Math.floor(duration.h) == 1)
            text += Math.ceil(duration.h) + " hour";
        else if(Math.floor(duration.h) > 1)
            text += Math.ceil(duration.h) + " hours";
        
        if(Math.floor(duration.m) == 1)
            text += Math.ceil(duration.m) + " min";
        else if(Math.floor(duration.m) > 1)
            text += Math.ceil(duration.m) + " mins";
        
        return text;
    },
    numToDuration : (n) =>{
        var seconds = n/1000;
        var minutes = n/60000;
        var hours = n/3600000;
        var days = n/86400000;

        return {d : days, h : hours , m: minutes , s : seconds};
    },
    extractTimezoneInfo : (d) =>{
        if(d.lastIndexOf("+") > 0)
            return d.substring(d.lastIndexOf("+"));
        else if(d.lastIndexOf("-") > 4)
            return d.substring(d.lastIndexOf("-"));
        else
            return "";
    },
    getWeekdayNames : () =>{
        return ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    },
    getDatesAsWeekdays: (startDt,endDt) => { 
        let wdNames= ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]; //fixit
        let wd = [];
        let cDate = startDt;
        while(cDate <= endDt){
            wd.push( wdNames[cDate.getDay()] );
            //console.log("For " + cDate + ", weekday is=" + wd[wd.length - 1]);
            cDate = DateUtils.addDays(cDate , 1);
        }
        return wd;
    },
    getStartEndTimeText: (startDt,endDt)=>{
        //Date/time format is 2020-10-11T23:00:00-04:00
        //let startHr = parseInt(data["start"].split("T")[1].split(":")[0]);
        //let endHr = parseInt(data["end"].split("T")[1].split(":")[0]);
        
        let startHr = parseInt(startDt.split("T")[1].split(":")[0]);
        let endHr = parseInt(endDt.split("T")[1].split(":")[0]);

        let startTimeText="";
        let endTimeText = "";

        if(startHr == 0) 
            startTimeText="12AM"; 
        else
            startTimeText = (startHr > 12 ? startHr - 12 : startHr) +
            (startHr > 12 ? "PM" : "AM");
        
        if(endHr == 0)
            endTimeText = "12AM";
        else
            endTimeText= 
            (endHr > 12 ? endHr - 12 : endHr) +
            (endHr > 12 ? "PM" : "AM");
        //console.log("startHr=" + startHr + ", endHr=" + endHr);
        return {st : startTimeText , et: endTimeText};
    }
};