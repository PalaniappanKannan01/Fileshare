/**
 * Various string utilities
 */
export const isEmpty = (v) => {
  console.log("Into isEmpty...");
  if (v == null || typeof v === "undefined") return true;
  v = v.toString();
  return v.trim().length == 0;
};
export const isLengthSmallerThan = (v, l) => {
  console.log("Into isLengthSmallerThan...");
  if (v == null || typeof v === "undefined") {
    return l > 0;
  }
  v = v.toString();
  return v.trim().length < l;
};
export const hasUppercaseLetter = (v) => {
  console.log("Into hasUppercaseLetter...");
  let numUpper = (v.match(/[A-Z]/g) || []).length;
  return numUpper > 0;
};

export const getInitials = (words) => {
  if (words == null || typeof words === "undefined") return "";
  let parts = words.split(" ");
  let initials = "";
  for (let i = 0; i < parts.length; i++) {
    initials += parts[i].split()[0].toUppercase();
  }
  return initials;
};

export const pad = (num, size) =>{
  num = num.toString();
  while (num.length < size) num = "0" + num;
  return num;
}