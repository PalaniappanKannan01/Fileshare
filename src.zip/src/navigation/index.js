import React,{Component} from "react";
import { createSwitchNavigator, createAppContainer } from 'react-navigation'
import AuthNavigation from './authNavigation';
import LoggedInStack from "./appNavigation";
import { NavigationContainer } from "@react-navigation/native";

const SwitchNavigator = createSwitchNavigator({
    Auth: AuthNavigation,
    Home: LoggedInStack
}, {
    initialRouteName: 'Auth'
});

const AppContainer = createAppContainer(SwitchNavigator)
export default AppContainer;
