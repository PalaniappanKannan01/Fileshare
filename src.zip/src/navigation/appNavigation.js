import React, { ReactElement, Component } from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { ResidentSummary} from '../views/residentSummary'
import {ResidentSettings} from '../views/residentSettings';
import { NavigationContainer, StackActions } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import {SummaryIcon,NotificationIcon,SettingsIcon} from "../controls/svgIcons";
import {Colors, Spacing, Typography} from "../style/allstyles";
import GetHelp from '../views/getHelp';
import MyProfile from "../views/myProfile";
import SleepCharts from '../views/sleepCharts';
import MobilityCharts from "../views/mobilityCharts";
import VitalsCharts from "../views/vitalsCharts";
import PersonalHygieneCharts from "../views/personalHygieneCharts";
import NutritionCharts from "../views/nutritionCharts";

//refer https://reactnavigation.org/docs/hiding-tabbar-in-screens/
const tab = createBottomTabNavigator();
const loggedIn = createStackNavigator();

function ResidentSummaryTabs() {
    return (
        <tab.Navigator 
                initialRouteName="Summary"
                tabBarOptions={{
                    labelStyle:{fontSize: Typography.tabItemText.fontSize},
                    activeTintColor: Colors.vinyaDefaultColor,
                  }}>
                <tab.Screen 
                        name="Summary" 
                        options={{
                            tabBarLabel: 'Summary',
                            tabBarIcon: ({ focused }) => {
                                if(focused)
                                    return (<SummaryIcon width={24} height={24} focus={focused}/>);
                                else
                                    return (<SummaryIcon width={24} height={24} focus={false}/>);
                            },
                        }}
                        component={ResidentSummary}/>
                    {/*
                <tab.Screen 
                    name="Notifications" 
                    options={{
                        tabBarLabel: 'Notifications',
                        tabBarIcon: ({ focused }) => {
                            if(focused)
                                return (<NotificationIcon width={24} height={24} focus={focused}/>);
                            else
                                return (<NotificationIcon width={24} height={24} focus={false}/>);
                        },
                    }}
                component={ResidentSummary}/>*/}
                <tab.Screen 
                    name="Settings" 
                    options={{
                        tabBarLabel: 'Settings',
                        tabBarIcon: ({ focused }) => {
                            if(focused)
                                return (<SettingsIcon width={24} height={24} focus={focused}/>);
                            else
                                return (<SettingsIcon width={24} height={24} focus={false}/>);
                        },
                    }}
                    component={ResidentSettings}/>
            </tab.Navigator>
    );
}
function LoggedInStack(){
    return(
        <NavigationContainer>
            <loggedIn.Navigator screenOptions={{ headerShown: false }}>
                <loggedIn.Screen name="ResidentSummary" component={ResidentSummaryTabs}></loggedIn.Screen>
                <loggedIn.Screen name="MyProfile" component={MyProfile}></loggedIn.Screen>
                <loggedIn.Screen name="GetHelp" component={GetHelp}></loggedIn.Screen>
                <loggedIn.Screen name="SleepCharts" component={SleepCharts}></loggedIn.Screen>
                <loggedIn.Screen name="MobilityCharts" component={MobilityCharts}></loggedIn.Screen>
                <loggedIn.Screen name="VitalsCharts" component={VitalsCharts}></loggedIn.Screen>
                <loggedIn.Screen name="HygieneCharts" component={PersonalHygieneCharts}></loggedIn.Screen>
                <loggedIn.Screen name="NutritionCharts" component={NutritionCharts}></loggedIn.Screen>
            </loggedIn.Navigator>
        </NavigationContainer>
    );
}

export default LoggedInStack;