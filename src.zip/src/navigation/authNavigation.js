import React from "react";
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from 'react-navigation-stack'
import LoginLanding from '../views/loginLanding';
import SignIn from '../views/login';
import SignUp from '../views/aws-authScreens/signUp';
import Splash from '../views/splash'
import LoginConfirm from "../views/loginConfirmation";


const AuthNavigation = createStackNavigator(
  {
    Splash: {screen:Splash},
    LoginLanding: { screen: LoginLanding },
    Login: { screen: SignIn },
    Signup: { screen: SignUp },
    LoginConfirm :{screen : LoginConfirm}
  },
  {
    initialRouteName: 'Splash',
    headerMode: 'none'
  }
);

export default AuthNavigation;