   /*
      Login page
   */
import React, { Component, useState } from 'react'
import { View, Text, TouchableOpacity, TextInput, StyleSheet, Linking, Platform } from 'react-native'
import { Auth, I18n, Logger } from 'aws-amplify';

import {ContainerStyles,ImageStyles, Typography, Spacing, Colors} from "../style/allstyles";
import {RoundedSolidButton,NavigatorButton} from "../controls/appbuttons";
import * as StringUtils from "../utils/stringutils";
import * as Constants from "../constants/constants";

export const SignIn = (props) => {
   const [state, setState] = useState({
      username: '',
      password: '',
      hidePassword: true,
   });
   
   login = (email, pass) => {
      if(StringUtils.isEmpty(email)){
         alert("Please enter your email");
      }else if(email.indexOf("@") < 2 || email.indexOf(".") < 2){
         alert("Please enter valid email");
      }else if(StringUtils.isEmpty(pass)){
         alert("Please enter your password");
      }else {
         return Auth.signIn(email, pass)
            .then(user => {
            console.log("Login successful: user=" + user);
            props.navigation.navigate('LoginConfirm');
         })
         .catch(err => {
            alert('Incorrect username or password');
            console.log('Login failed...'+ err);
         });
      }
   }
   return (
      <View style={ContainerStyles.pageContainer}>
         <NavigatorButton text="Start" onPress={()=> props.navigation.navigate('LoginLanding')}></NavigatorButton>
         <View style={{flex:5}}>
            <Text style={[Typography.H1, {paddingLeft:16}]}>Log in to continue</Text>
            <Text style={[Typography.label, Spacing.superLargeTopMargin]}>Your Email Address</Text>
            <TextInput style = {ContainerStyles.input}
               underlineColorAndroid = "transparent"
               placeholder = "e.g. Jane@gmail.com"
               placeholderTextColor = {Colors.lightGray}
               autoCapitalize = "none"
               onChangeText = {(text) => setState({...state, username: text})}/> 
            <Text style={Typography.label}>Your Password*</Text>
            <View style={ContainerStyles.textBoxContainer}>
               <TextInput style = {ContainerStyles.input}
                  underlineColorAndroid = "transparent"
                  placeholder = "........."
                  placeholderTextColor ={Colors.lightGray}
                  secureTextEntry={state.hidePassword}
                  autoCapitalize = "none"
                  onChangeText = {(text) => setState({...state, password: text})}/>
               <TouchableOpacity activeOpacity={0.8} 
                  style={ContainerStyles.touachableButton} 
                  onPress={() => setState({...state, hidePassword: !state.hidePassword})}>
                  <Text>{(state.password.length > 0) 
                  ? <Text style={ContainerStyles.buttonPass}>{(state.hidePassword) ? 'Show' : 'Hide'}</Text>
                  : ''}
                  </Text>
               </TouchableOpacity>
            </View>
            <View style={Spacing.defaultLeftPad}>
               <Text >*Your password has to be at least 8 characters long
                  and should include at least 1 uppercase letter.
               </Text>
            </View>
         </View>
         <View style={{flex:2}}>
            <View style={Spacing.defaultLeftPad}>
               <Text>Having troubles signing in?</Text>
               <Text 
                  style={[Typography.anchor, Spacing.defaultTopMargin]}
                  onPress={()=>{Linking.openURL("tel://" + Constants.HELPDESK_PHONE)}}>{Constants.HELPDESK_PHONE}</Text>
               <Text 
               style={[Typography.anchor, Spacing.defaultTopMargin]}
                  onPress={()=>{Linking.openURL("mailto:" + Constants.HELPDESK_EMAIL)}}>{Constants.HELPDESK_EMAIL}</Text>
            </View>
            
            <RoundedSolidButton
               onPress={()=>login(state.username, state.password)}
               cstyle={{width:"94%"}}
               text="Log in"></RoundedSolidButton>
         </View>
         
      </View>
   );
}
export default SignIn;
      