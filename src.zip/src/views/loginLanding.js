/**
 * Login landing page...
 */
import React, { Component } from 'react';
import {
    SafeAreaView,
    StyleSheet,
    Button,
    View,
    Text,
    Image,
    TouchableOpacity,
    Dimensions,
} from 'react-native';
import {ContainerStyles,ImageStyles, Typography, Spacing} from "../style/allstyles";
import {RoundedSolidButton} from "../controls/appbuttons";
import {AuthApi} from "../api/auth";
import { VIDALogo , HomeWithLamp } from '../controls/svgIcons';

export default class LoginLanding extends Component{
    componentDidMount(){
        /*If already logged in then move to summary screen */
        AuthApi.isLoggedIn().then((r) => {
            if(r){
                console.log("User logged in...navigating to login confirm");
                this.props.navigation.navigate("LoginConfirm");
            }
        });
    }
    render(){
        return (
            <View style={ContainerStyles.pageContainer}>
                <View style={[ContainerStyles.absPageCenter , Spacing.extraLargeTopMargin, {flex:1}]}>
                    <VIDALogo
                        width= {ImageStyles.vidaLogo.width}
                        height={ImageStyles.vidaLogo.height}
                    />
                </View>
                <View style={[ContainerStyles.absPageCenter , Spacing.superLargeTopMargin,, {flex:3}]}>
                    <HomeWithLamp width={"100%"}></HomeWithLamp>
                </View>
                <View style={{flex:6 , flexDirection:"column",
                        justifyContent:"center" ,
                        width:"100%",
                        }}>
                    <Text style={[Typography.H1 , {textAlign:"center"}]}>Be independent in your own home</Text>
                    <Text style={[Spacing.largeTopMargin,{textAlign:"center"}]}>Intelligent monitoring for a better independent life</Text>
                    <RoundedSolidButton
                        text="Log in"
                        bstyle={{alignItems:"center"}}
                        onPress={() => this.props.navigation.navigate('Login')}
                        ></RoundedSolidButton>   
                    <View style={[Spacing.largeTopMargin, {flex:1, flexDirection:"row", 
                        justifyContent:"center",
                        }]}>
                        <Text>Don't yet have an account? </Text>
                        <Text 
                            onPress = {() => this.props.navigation.navigate('Signup')} 
                            style={Typography.anchor}>Sign up</Text>
                    </View>
                </View>
            </View>
        );
    }
}
