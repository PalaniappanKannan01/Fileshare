import React, { Component, useState } from 'react'
import { View, Text, TouchableOpacity, TextInput, StyleSheet, Linking } from 'react-native'
import { Auth, I18n, Logger } from 'aws-amplify';
import Icon from 'react-native-vector-icons/AntDesign';
import { ScrollView } from 'react-native-gesture-handler';

import {ContainerStyles,ImageStyles, Typography, Spacing, Colors} from "../../style/allstyles";
import {RoundedSolidButton,NavigatorButton} from "../../controls/appbuttons";
import * as StringUtils from "../../utils/stringutils";
import * as Constants from "../../constants/constants"

export const SignUp = (props) => {
    const [state, setState] = useState({
        username: '',
        email: '',
        password: '',
        hidePassword: true,
    });
    const [error, setErrors] = useState({
        email: '',
        password: '',
        hideError: true,
    });
    
    handleUsername = (text) => {
        this.setState({ username: text })
    }

    handlePassword = (text) => {
        this.setState({ password: text })
    }

    signUp = (username, email, pass) => {
        console.log('email: ' + email + ' password: ' + pass, username);
        if(StringUtils.isEmpty(username))
            alert("Please enter your name");
        if(StringUtils.isEmpty(email))
            alert("Please enter your email");
        else if(email.indexOf("@") < 2)
            alert("Please enter a valid email");
        else if(StringUtils.isEmpty(pass))
            alert("Please enter your password");
        else if(pass.trim().length < Constants.MAX_PWD_LENGTH)
            alert("Password must contain " + Constants.MAX_PWD_LENGTH + " letters");
        else if(!StringUtils.hasUppercaseLetter(pass)){
            alert("Password must contain at least 1 uppercase letter");
        }else {
            return Auth.signUp({
                username: email,
                password: pass,
                attributes: {
                    email: email,
                    'custom:name': username          // optional
                }
            })
            .then(user => {
                //   logger.debug(user);
                alert('Signed up successfully');
                props.navigation.navigate('Login');
                console.log('user', user);
            })
            .catch(err => {
                alert(err.message);
                console.log('not sucessful', err);
            });
        }
    }

        return (
            <View style={ContainerStyles.pageContainer}>
                <NavigatorButton text="Start" onPress={()=> props.navigation.navigate('LoginLanding')}></NavigatorButton>
                <View style={{flex:3}}>
                    <Text style={[Typography.H1, {paddingLeft:16}]}>Let's get started</Text>
                    <Text style={[Typography.label, Spacing.superLargeTopMargin]}>Your Name</Text>
                    <TextInput style={ContainerStyles.input}
                        underlineColorAndroid="transparent"
                        placeholder="e.g. Jane Smith"
                        placeholderTextColor={Colors.lightGray}
                        autoCapitalize="none"
                        onChangeText={(text) => setState({ ...state, username: text })} />

                    <Text style={Typography.label}>Your Email Address</Text>
                    <TextInput style={ContainerStyles.input}
                        underlineColorAndroid="transparent"
                        placeholder="e.g. Jane@gmail.com"
                        placeholderTextColor={Colors.lightGray}
                        autoCapitalize="none"
                        onChangeText={(text) => setState({ ...state, email: text.toLowerCase() })} />
                    
                    <Text style={Typography.label}>Your Password*</Text>
                        <View style={ContainerStyles.textBoxContainer}>

                        <TextInput style={ContainerStyles.input}
                            underlineColorAndroid="transparent"
                            placeholder="........."
                            placeholderTextColor={Colors.lightGray}
                            secureTextEntry={state.hidePassword}
                            autoCapitalize="none"
                            onChangeText={(text) => setState({ ...state, password: text })} />
                            <TouchableOpacity activeOpacity={0.8} 
                                style={ContainerStyles.touachableButton} 
                                onPress={() => setState({...state, hidePassword: !state.hidePassword})}>
                                <Text>{(state.password.length > 0) 
                                ? <Text style={ContainerStyles.buttonPass}>{(state.hidePassword) ? 'Show' : 'Hide'}</Text>
                                : ''}
                                </Text>
                            </TouchableOpacity>
                        </View>
                        <View style={Spacing.defaultLeftPad}>
                            <Text >*Your password has to be at least 8 characters long and should include at least 1 uppercase letter.
                            </Text>
                        </View>
                </View>

                <View style={{flex:1}}>
                    <RoundedSolidButton
                        onPress={() => signUp(state.username, state.email, state.password)}
                        cstyle={{width:"94%"}}
                        text="Continue"></RoundedSolidButton>

                    <View style={Spacing.defaultPad}>
                        <Text style={{paddingLeft:12}}>By continuing you agree to our
                        <Text style={Typography.anchor} onPress={()=> Linking.openURL(Constants.TNC_URL)} > Terms and Conditions </Text> 
                        and our <Text style={Typography.anchor} onPress={()=> Linking.openURL(Constants.PP_URL)} > Privacy Policy </Text> 
                        </Text>
                    </View>
                </View>
            </View>
        )
}

export default SignUp;