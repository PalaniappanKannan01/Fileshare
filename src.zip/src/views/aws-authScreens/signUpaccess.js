import React, { Component, useState } from 'react'
import { View, Text, TouchableOpacity, TextInput, StyleSheet } from 'react-native'
import { Auth, I18n, Logger } from 'aws-amplify';
import Icon from 'react-native-vector-icons/AntDesign';
import { ScrollView } from 'react-native-gesture-handler';
import { validateEmail } from '../../validation/validation';
// import { Home } from '../views/home';
// import { createStackNavigator } from '@react-navigation/stack';

const GET = 'GET';
const API_URL = 'https://api.vinyaservices.com/vida';
export default class SignUpAccess extends Component {
    constructor(props) {
        super(props);
        this.state = {
            user: Auth.currentAuthenticatedUser({
                bypassCache: false // Optional, By default is false. If set to true, this call will send a request to Cognito to get the latest user data
            }),
            usedId: '',
            username: '',
            hideError: true,
            error: '',
        };
    }

    getAuthKey() {
        const emailError = validateEmail(this.state.username);
  
        if (emailError) {
            this.setState({error: emailError, hideError: false});
            // setErrors({email: emailError, password: passwordError, hideError: false});
        } else {
        return this.state.user.then(user => {
            this.setState({hideError: true});
            user.getSession((err, session) => {
            if (err) {
                throw new Error(err);
            }
            const sessionToken = session.getIdToken().jwtToken;
            this.makeRequest(sessionToken);
            })
        });
       }
    }

    async makeRequest(sessionToken) {
        return fetch(API_URL + '/access/request?email=' + this.state.username, {
            method: 'POST',
            headers: {
            'Authorization': sessionToken
            },
        })
        .then(res => 
            console.log(res.json())
            )
        .catch(err => {
            console.log('not sucessful', err);
            });
        ;
    }

    render() {
        return (
            <ScrollView>
                <View style={styles.container}>
                    <View>
                        <Text style={styles.title}>Request access</Text>
                        <Text style={styles.passwordRegularmsg}>You can now request access to a home to see the resident's data.</Text>
                        <Text style={styles.text}>THEIR EMAIL ADDRESS</Text>
                        <TextInput style={styles.input}
                            underlineColorAndroid="transparent"
                            placeholder="e.g. Jane@gmail.com"
                            placeholderTextColor="#868E96"
                            autoCapitalize="none"
                            onChangeText={(text) => this.setState({ ...this.state, username: text })} />
                    </View>
                    <Text style={styles.validationTxt}>{(!this.state.hideError) ? this.state.error : ''}</Text>

                    <View>
                        <TouchableOpacity
                            style={styles.submitButton}
                            onPress={() => this.getAuthKey()}>
                            <Text style={styles.submitButtonText}> Request access </Text>
                        </TouchableOpacity>
                    </View>

                </View >
            </ScrollView >
        )
    }

}


const styles = StyleSheet.create({
    container: {
        paddingTop: 40,
        flex: 1,
        justifyContent: 'center',
        margin: 'auto',
        width: '100%',
        marginBottom:10
    },
    navigator: {
        paddingLeft: 10,
    },
    navigatorText: {
        fontSize: 14,
        color: '#212529',
    },
    input: {
        margin: 10,
        height: 48,
        borderColor: '#DEE2E6',
        borderWidth: 3,
        borderRadius: 10,
        paddingLeft: 16,
        fontSize: 16,
    },
    validationTxt: {
        fontSize: 16,
        color: 'red',
        paddingLeft: 15,
     },
    title: {
        fontSize: 32,
        paddingLeft: 20,
        fontWeight: 'bold',
        marginBottom: 30,
    },
    text: {
        fontSize: 14,
        color: '#212529',
        textTransform: 'uppercase',
        paddingLeft: 20,
        marginTop: 35,
        fontWeight: 'bold',
    },
    passwordRegularmsg: {

        fontSize: 16,
        color: '#212529',
        paddingLeft: 20,
        flexWrap: "wrap",
        marginTop: 15
    },
    submitButton: {
        backgroundColor: '#7a42f4',
        padding: 10,
        margin: 15,
        height: 48,
        borderRadius: 24,
        marginTop: 40,
    },
    goBackButton: {
        padding: 10,
        margin: 15,
        height: 48,
        marginTop: 5,
        backgroundColor: '#FFFFFF',
        borderColor: '#DEE2E6',
        borderWidth: 1,
        borderRadius: 24,
        justifyContent: 'center',
        alignItems: 'center',
    },
    submitButtonText: {
        color: 'white',
        textAlign: 'center',
        fontSize: 16,
    },
    gobackButtonText: {
        color: '#868E96',
        fontSize: 16,
    }
})