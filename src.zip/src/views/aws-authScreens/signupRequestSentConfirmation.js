import React, { PureComponent } from 'react'

import {
StyleSheet,
View,
Text,
Image,
TouchableOpacity,
SafeAreaView,
Button,
ScrollView
} from 'react-native';
import Icon from 'react-native-vector-icons/AntDesign';

export const SignupRequestSentConfirmation = () => {
  return(
  <View style={{flex:2,justifyContent:'space-between'}}>
    <View style={styles.navigator}>
      <Icon.Button name="left" backgroundColor="transparent" color="#212529" size={15}>
        <Text style = {styles.navigatorText}>Request acceess</Text>
      </Icon.Button>
    </View>
    <View style={{marginTop:120}}>
      <Text style={styles.headText}>Your request was sent!</Text>
      <Text style={styles.midText}>You will be notified when Mary Jane has accepted your request.</Text>
    </View>
    <View style={{marginTop:40,flex:1}}>
      <Image source={require('vinya/src/assets/images/mail.png')} style={styles.mailIcon} />
        <View style={styles.invite}>
        <TouchableOpacity>
          <Text style={styles.inviteText}>Request access to another home</Text>
        </TouchableOpacity>
        </View>
        <View style={styles.explore}>
        <TouchableOpacity>
          <Text style={styles.exploreText}>Explore VIDA</Text>
        </TouchableOpacity>
        </View>
    </View>
  </View>
  )
}

const styles = StyleSheet.create({
invite:{
  borderColor:'#7a42f4',
  padding: 10,
  marginHorizontal: 15,
  marginTop: 75,
  height: 48,
  borderWidth:1,
  borderRadius: 24,
},

navigator: {
  paddingLeft: 10,
},

navigatorText: {
  fontSize: 14,
  color: '#212529',
},

explore:{
  backgroundColor:'#7a42f4',
  padding: 10,
  marginHorizontal: 15,
  marginVertical: 12,
  height: 48,
  borderWidth:1,
  borderRadius: 24,
},

inviteText:{
  color: 'white',
  textAlign: 'center',
  fontSize: 16,
  color:'#7a42f4'
},

exploreText:{
  textAlign: 'center',
  fontSize: 16,
  color:'#ffffff'
},

headText:{
  // position:'absolute',
  fontStyle:"SF Pro Text",
  fontWeight:'700',
  fontStyle:'normal',
  textAlign: 'center',
  fontSize:24,
  lineHeight:30,
  marginTop:10,
  marginHorizontal: 120,
},

iconSection:{
  marginTop:40,
},

mailIcon:{
  width: 90,
  height: 90,
  marginLeft:160,
  marginBottom:20
},

midText:{
  fontStyle:"SF Pro Text",
  fontWeight:'400',
  fontStyle:'normal',
  fontSize:16,
  lineHeight:24,
  textAlign:'center',
  marginTop: 12,
  marginHorizontal: 35,
}
})