import React, { PureComponent } from 'react'

import {
StyleSheet,
View,
Text,
Image,
TouchableOpacity,
SafeAreaView,
Button,
ScrollView
} from 'react-native';

export const InvitationConfirmation = () => {
  return(
  <View style={{flex:2,justifyContent:'space-between'}}>
    <View style={{marginTop:150}}>
      <Text style={styles.headText}>Your invitation was sent!</Text>
      <Text style={styles.midText}>You will be notified when Nick Miller has accepted your invitation and start having access to your data,</Text>
    </View>
    <View style={{marginTop:40,flex:1}}>
      <Image source={require('vinya/src/assets/images/mail.png')} style={styles.mailIcon} />
      <View style={styles.invite}>
        <TouchableOpacity>
          <Text style={styles.inviteText}>Invite more people</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.explore}>
        <TouchableOpacity>
          <Text style={styles.exploreText}>Explore VIDA</Text>
        </TouchableOpacity>
      </View>
    </View>
  </View>
  )
}

const styles = StyleSheet.create({
invite:{
  borderColor:'#7a42f4',
  padding: 10,
  marginHorizontal: 15,
  marginTop: 60,
  height: 48,
  borderWidth:1,
  borderRadius: 24,
},

explore:{
  backgroundColor:'#7a42f4',
  padding: 10,
  marginHorizontal: 15,
  marginVertical: 12,
  height: 48,
  borderWidth:1,
  borderRadius: 24,
},

inviteText:{
  color: 'white',
  textAlign: 'center',
  fontSize: 16,
  color:'#7a42f4'
},

exploreText:{
  textAlign: 'center',
  fontSize: 16,
  color:'#ffffff'
},

headText:{
  // position:'absolute',
  fontStyle:"SF Pro Text",
  fontWeight:'700',
  fontStyle:'normal',
  textAlign: 'center',
  fontSize:24,
  lineHeight:30,
  marginTop:10,
  marginHorizontal: 110,
},

iconSection:{
  marginTop:40,
},

mailIcon:{
  width: 90,
  height: 90,
  marginLeft:160,
  marginBottom:20
},

midText:{
  fontStyle:"SF Pro Text",
  fontWeight:'400',
  fontStyle:'normal',
  fontSize:16,
  lineHeight:24,
  textAlign:'center',
  marginTop: 12,
  marginHorizontal: 35,
}
})