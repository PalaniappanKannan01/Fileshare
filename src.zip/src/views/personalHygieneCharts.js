import React, { Component } from 'react'
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  Alert,
  Image,
  TouchableOpacity,
  ImageBackground
} from 'react-native';
import { Auth } from 'aws-amplify';
import * as Constants from "../constants/constants";
import { ContainerStyles, ImageStyles, Typography , Colors, Spacing} from '../style/allstyles';
import {NavigatorNoTextButton} from "../controls/appbuttons";
import { AdlApi } from '../api/adl';
import { DayRangePicker } from '../controls/dayRangePicker';
import { DayRangeScroller } from '../controls/dayRangeScroller';
import { DateUtils } from '../utils/dateutils';
import { ChartDataSummary } from '../controls/chartDataSummary';
import { PersonalHygieneActivity24HrChart } from "../controls/personalHygieneActivity24hr";
import { PersonalHygieneActivityWeeklyChart } from "../controls/personalHygieneActivityWeekly";
import { AvatarIcon } from '../controls/svgIcons';

export default class PersonalHygieneCharts extends Component {
  that = null;
  constructor() {
    super();
    
    this.state = {
      filter:Constants.ActivityDataFilters.day,
      start_dt_offset: 0, 
      tplabel : "",
      summaryHeaderText:"",
      summaryValueText:"",
      summaryFooterText:"",
      data:{}
    };
    that = this;
  }
  refreshChartData(range, offset) {
    
    console.log("Activity Charts::Into refreshChartData")
    if(offset > 0){
      alert("No data for future dates");
    }else
    {  //load the data...
      AdlApi.getUserSummary((d,e)=>{
        if(e != null){
          alert("Failed to get activity data." + e);
          this.props.navigation.navigate("ResidentSummary");
        }else{
          let userId = d["residents"][0]["id"];
          AdlApi.getActivityData(userId , "hygiene", range , offset,
          (json,err)=>{
            if(err != null){
              alert("Failed to get activity data." + err);
              this.props.navigation.navigate("ResidentSummary");
            }else{
              console.log(JSON.stringify(json));
              
              this.setState({
                filter: range,
                start_dt_offset: offset,
                tplabel: json["timePeriodLabel"],
                toiletSummaryHeaderText:json["toilet"]["summary"]["headerText"],
                toiletSummaryValueText:json["toilet"]["summary"]["value"],
                toiletSummaryFooterText: json["toilet"]["summary"]["footerText"],
                bathSummaryHeaderText:json["bath"]["summary"]["headerText"],
                bathSummaryValueText:json["bath"]["summary"]["value"],
                bathSummaryFooterText: json["bath"]["summary"]["footerText"],
                data: json
              });
              that = this;
            }
          });
        }
      });
    }
  }

  onDayRangePickerChange(d){
    if(d == Constants.ActivityDataFilters.day)
      startDt_offset = -1
    else if(d == Constants.ActivityDataFilters.week)
      startDt_offset = -7
    else if(d == Constants.ActivityDataFilters.month)
      startDt_offset = -30 //not considering 31 for now
    else if(d == Constants.ActivityDataFilters.year)
      startDt_offset = -365;

    that.refreshChartData(d , startDt_offset);
  }

  onDayRangeScrolledNext(){
    console.log("hygieneCharts::onDayRangeScrolledNext...Current Start Dt=" + that.state.start_dt);
    
    let nextOffset = that.getNextOffset(false,that.state.filter) + that.state.start_dt_offset;
    
    that.refreshChartData(that.state.filter, nextOffset);
  }

  onDayRangeScrolledPrev(){
    console.log("hygieneCharts::onDayRangeScrolledPrev...");
    let nextOffset = that.getNextOffset(true,that.state.filter) + that.state.start_dt_offset;
    that.refreshChartData(that.state.filter, nextOffset);
  }
  getNextOffset(prev, filter){
    let offset = 0;
    if(filter == Constants.ActivityDataFilters.day)
      offset = prev ? -1:1;
    else if(filter == Constants.ActivityDataFilters.week)
      offset = prev ? -7:7;
    else if(filter == Constants.ActivityDataFilters.month)
      offset = prev ? -30:30;
    else
      offset = prev ? -365:365 
     
    return offset;
  }
  render() {
    console.log("Hygiene Activity Charts::Into render...");
    if(this.state.tplabel == "" /**first time */){
      this.refreshChartData(Constants.ActivityDataFilters.day , this.state.start_dt_offset);
    }
    let the_chart = <View></View>;
    if(this.state.filter == Constants.ActivityDataFilters.day)
      the_chart = <PersonalHygieneActivity24HrChart chartData={this.state.data}></PersonalHygieneActivity24HrChart>;
    else if(this.state.filter == Constants.ActivityDataFilters.week)
      the_chart = <PersonalHygieneActivityWeeklyChart chartData={this.state.data}></PersonalHygieneActivityWeeklyChart>
    return (
      <View style={ContainerStyles.pageContainer}>
        <View style={[ContainerStyles.adlChartsHeader , {flex:1.5, borderBottomColor:"#bababa", borderBottomWidth:1}]}>
          <NavigatorNoTextButton onPress={()=> this.props.navigation.navigate('ResidentSummary')}></NavigatorNoTextButton>
          <Text style={[Typography.H3,, {marginLeft:20}]}>Personal Hygiene</Text>  
          <AvatarIcon style={{marginRight:Spacing.largePad.padding}}></AvatarIcon>
        </View>
        <View style={{flex:1}}>
          {/*<ImageBackground 
            style={{width:"100%", height:24, margin:0, padding:0}}
          source={require("../assets/images/gradient_background.png")}></ImageBackground>*/}
          <DayRangePicker 
            onChange={this.onDayRangePickerChange}
            tsfilter={this.state.filter}></DayRangePicker>
        </View>
        <DayRangeScroller 
            timePeriodLabel={this.state.tplabel}
            onPrev={this.onDayRangeScrolledPrev}
            onNext={this.onDayRangeScrolledNext}></DayRangeScroller>
        <View style={{flex:2}}>
          <ChartDataSummary 
              headerText={this.state.toiletSummaryHeaderText}
              valueText={this.state.toiletSummaryValueText}
              footerText={this.state.toiletSummaryFooterText}></ChartDataSummary>
          <View style={Spacing.defaultTopMargin}>
            <ChartDataSummary 
                headerText={this.state.bathSummaryHeaderText}
                valueText={this.state.bathSummaryValueText}
                footerText={this.state.bathSummaryFooterText}></ChartDataSummary>
          </View>
          
        </View>
        <View style={{flex:6, padding:12}}>
          {the_chart}
        </View>
        <View style={[Spacing.extraLargePad, {flex:1, marginTop: 20}]}>
          <Text onPress={()=>Linking.openURL(Constants.MISSING_DATA_INFO_URL)} 
              style={Typography.anchor}>Need help understanding this data?</Text>    
        </View>
      </View>
    )
  }
}