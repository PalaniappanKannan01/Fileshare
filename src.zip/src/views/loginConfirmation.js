import React, { Component } from 'react'

import {
StyleSheet,
View,
Text,
Image,
} from 'react-native';
import {ContainerStyles,ImageStyles, Typography, Spacing, Colors} from "../style/allstyles";
import {RoundedSolidButton,RoundedBorderButton} from "../controls/appbuttons";
import { GreenTick } from '../controls/svgIcons';
import { AuthApi } from '../api/auth';
import { Auth } from 'aws-amplify';

export default class LoginConfirm extends Component {
  logout(){
    AuthApi.logout()
      .then(()=>{
        this.props.navigation.navigate("Login");
      })
      .catch(err => {
        console.log(err);
        alert("Failed to logout.Please try again.Contact us if problem persists.");
      });
  }
  render(){
    
    return(
      <View style={[ContainerStyles.pageContainer , ContainerStyles.absPageCenter]}>
          <View style={{flex:1}}></View>
          <View style={[ContainerStyles.absPageCenter,{flex:3}]}>
            <GreenTick width={ImageStyles.bigIcon.width} height={ImageStyles.bigIcon.height}/>
            
            <Text style={[Typography.H1, Spacing.defaultTopMargin]}>You're all set!</Text>
            <Text style={Spacing.largePad}>You are now connected to the VIDA sensors in your home. Explore your data or give permission to someone else to view your data.</Text>
          </View>
          <View style={{flex:1, width:"100%"}}>
            {/*
            <RoundedBorderButton
                          onPress={() =>{this.props.navigation.navigate("InviteSomeone")} }
                          cstyle={{width:"94%"}}
                          text="Invite Someone"></RoundedBorderButton>
            */}
            <RoundedSolidButton
                          onPress={() =>{this.props.navigation.navigate("Home")} }
                          cstyle={{width:"94%"}}
                          text="Continue"></RoundedSolidButton>
            <RoundedBorderButton
                          onPress={() =>{this.logout()} }
                          cstyle={{width:"94%"}}
                          text="Logout"></RoundedBorderButton>
          </View>
      </View>
      );
  }
}