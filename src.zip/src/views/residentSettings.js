import React, { PureComponent, Component } from 'react';
import { View, Image,Text } from 'react-native';
import { Dimensions, StatusBar } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import {AdlApi} from "../api/adl";
import {AuthApi} from "../api/auth";
import { NavigatorNoTextButton,RoundedBorderButton } from '../controls/appbuttons';
import { AvatarIcon, HelpIcon, InfoIcon } from '../controls/svgIcons';
import { ContainerStyles, ImageStyles, Typography, Colors, Spacing } from '../style/allstyles';
import { NavigationActions } from 'react-navigation';
import { useRoute } from '@react-navigation/native';

export class ResidentSettings extends Component{
    componentDidMount(){
        AuthApi.isLoggedIn().then((r)=>{
            if(!r)
                this.props.navigation.navigate("Auth");
        });
    }
    
    gotoHelp(){
        this.props.navigation.navigate("GetHelp");
    }
    gotoMyProfile(){
        this.props.navigation.navigate("MyProfile");
    }
    render(){
        return(
            <View style={[ContainerStyles.pageContainer, Spacing.extraLargePad]}>
                <View style={{flex:1, 
                    flexDirection:"row",
                    justifyContent:"flex-start",
                    alignItems:"center",
                    borderBottomColor: Colors.lightGray,
                    borderBottomWidth:1,
                    marginTop: Spacing.largeTopMargin.marginTop}}>
                    <AvatarIcon></AvatarIcon>
                    <View style={{flex:1, flexDirection:"column", paddingLeft:Spacing.defaultLeftPad.paddingLeft}}>
                        <Text style={Typography.H1}>My profile</Text>
                        <Text style={[Typography.adlInfo, Spacing.defaultTopMargin]}>edit profile</Text>
                    </View>
                </View>
                <View style={{flex:1, 
                        flexDirection:"column",
                        justifyContent:"flex-start",
                        alignItems:"flex-start",
                        width:"100%"}}>
                    <View style={{flex:1, flexDirection:"row", 
                            width:"100%", 
                            alignItems:"center",
                            justifyContent:"flex-start"}}>
                        <InfoIcon></InfoIcon>
                        <Text
                            onPress = {()=>this.gotoMyProfile()} 
                            style={{paddingLeft: Spacing.defaultLeftPad.paddingLeft, width:"85%"}}>My info</Text>
                        <NavigatorNoTextButton 
                            onPress = {()=>this.gotoMyProfile()}
                            dir="right"></NavigatorNoTextButton>
                    </View>
                    <View style={{flex:1, flexDirection:"row", 
                            width:"100%", 
                            alignItems:"center",
                            justifyContent:"flex-start"}}>
                        <HelpIcon></HelpIcon>
                        <Text
                            onPress = {()=>this.gotoHelp()} 
                            style={{paddingLeft: Spacing.defaultLeftPad.paddingLeft, width:"85%"}}>Get help</Text>
                        <NavigatorNoTextButton 
                            onPress = {()=>this.gotoHelp()}
                            dir="right"></NavigatorNoTextButton>
                    </View>
                </View>
                <View style={{flex:4}}></View>
            </View>
        );
    }
}
