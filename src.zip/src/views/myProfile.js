import React, { PureComponent, Component } from 'react';
import { View, Image,Text, TextInput, PermissionsAndroid } from 'react-native';
import { Dimensions, StatusBar } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import {AdlApi} from "../api/adl";
import {AuthApi} from "../api/auth";
import Amplify, { Auth } from "aws-amplify";
import { NavigatorButton, RoundedSolidButton } from '../controls/appbuttons';
import { AvatarIcon, CameraIcon, HelpIcon, InfoIcon } from '../controls/svgIcons';
import { ContainerStyles, ImageStyles, Typography, Colors, Spacing } from '../style/allstyles';
import {Avatar} from "../controls/avatar";
import * as StringUtils from "../utils/stringutils";

export default class MyProfile extends Component{
    constructor(){
        super();
        this.state ={name:'',email:'',profileUrl:''};
    }
    componentDidMount(){
        AuthApi.isLoggedIn().then((r)=>{
            if(!r)
                this.props.navigation.navigate("LoginLanding");
            else{
                //get Vida user...
                AdlApi.getUserSummary( (u,e) =>{
                    if(u) {
                        
                        let name = u["name"].split(" ");
                        this.setState({name: u["name"]});
                        this.setState({email: u['email']});
                        this.setState({profileUrl : u['profilePictureLink']});
                    /* TODO::
                        AdlApi
                            .getUserAvatar(this.state.email)
                            .then((resp)=>{
                                //console.log(resp);
                                return resp.json();
                            }).then(json =>{
                                //console.log(json.Body.data);
                                let arrBuf = new Uint8Array(json.Body.data);
                                let blob = new Blob( [arrBuf], { type: json.ContentType } );
                                //console.log(blob.toBase64());
                                //fixit
                            }).catch(err => {
                                console.log("ERROR::" + err);//do nothing for now on this...
                            });
                            */
                    }
                    
                } );
            }
        });
    }
    saveProfile(){
        if(StringUtils.isEmpty(this.state.name))
            alert("Please enter your name");
        else{
            AdlApi.updateName(this.state.name)
                .then((r)=>{
                    console.log("updateName = " + JSON.stringify(r));
                    if(r.status == 200){
                        alert("Name updated successfully");
                    }
                }).catch((err)=>{
                    alert("Failed to update name changes");
                });
        }
    }
    render(){
        return(
            <View style={[ContainerStyles.pageContainer]}>
                <NavigatorButton text="Settings" onPress={()=> this.props.navigation.navigate('ResidentSummary')}></NavigatorButton>
                <View style={{flex:1, paddingLeft: Spacing.defaultLeftPad.paddingLeft}}>
                    <Text style={Typography.H1}>My profile</Text>
                </View>
                <View style={{flex:1, flexDirection:"row", justifyContent:"center", alignItems:"center"}}>
                    <AvatarIcon></AvatarIcon>
                </View>
                <View style={{flex:0.5, marginTop: Spacing.extraLargeTopMargin.marginTop, flexDirection:"row", justifyContent:"center",alignItems:"center"}}>
                    
                    {/*<CameraIcon></CameraIcon>
                    <Text style={{paddingLeft:6}} onPress={()=>alert("Change picture")}>Change my picture</Text>
                    */}
                    </View>
                <View style={{flex:3, marginTop: Spacing.extraLargeTopMargin.marginTop, 
                    flexDirection:"column", justifyContent:"flex-start",
                    alignItems:"flex-start"}}>
                    <Text style={Typography.label}>Your name</Text>
                    <TextInput style = {[ContainerStyles.input, {width:"90%"}]}
                        underlineColorAndroid = "transparent"
                        autoCapitalize = "none"
                        value = {this.state.name}
                        onChangeText = {(text) => this.setState({...this.state, name: text})}/>

                    <Text style={[Typography.label, Spacing.largeTopMargin]}>Email</Text>
                    <TextInput style = {[ContainerStyles.input, {width:"90%", color:Colors.mediumGray}]}
                        autoCapitalize = "none"
                        editable={false}
                        value={this.state.email}
                        onChangeText = {(text) => this.setState({...this.state, email: text})}/> 
                </View>
                <View style={{flex:1}}></View>
                <View style={{flex:1}}>
                    <RoundedSolidButton
                        onPress={()=>this.saveProfile()}
                        cstyle={{width:"94%"}}
                        text="Save"></RoundedSolidButton>
                    </View>
            </View>
        );
    }
}
