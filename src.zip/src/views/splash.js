import React, { Component } from "react";
import {
    View,
    Image,
    Text
} from 'react-native';
import { AuthApi } from "../api/auth";
import {ContainerStyles,ImageStyles, Typography, Spacing} from "../style/allstyles";
import { VIDALogo } from '../controls/svgIcons';
/**
 * Splash screen implementation
 */
export default class Splash extends Component {
    /**
     * Create timeout and navigate away to the login screen
     */
    componentDidMount(){
        this.timeoutHandle = setTimeout(() => {
            //We navigate to login screen...that screen will worry if user is logged in or not
            console.log("Splash::componentDidMount...navigating to login landing...");
            this.props.navigation.navigate("LoginLanding");
        }, 3000);
    }
    componentWillUnmount() {
        clearTimeout(this.timeoutHandle); // This is just necessary in the case that the screen is closed before the timeout fires, otherwise it would cause a memory leak that would trigger the transition regardless, breaking the user experience.
    }
    render(){
        return (
            <View style={[ContainerStyles.pageContainer, ContainerStyles.absPageCenter]}>
                    {/* <View> */}
                    <VIDALogo
                        width={ImageStyles.vidaLogo.width}
                        height={ImageStyles.vidaLogo.height}
                    />
                    <Text style={[Typography.boldBodyText, Spacing.largeTopMargin]}>VIDA</Text>
            </View>
        );
    }
}

