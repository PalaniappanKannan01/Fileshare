import React, { Component, useState } from 'react'
import { View, Text, TouchableOpacity, TextInput, StyleSheet, Linking, Platform } from 'react-native'
import { Auth, I18n, Logger } from 'aws-amplify';

import {ContainerStyles,ImageStyles, Typography, Spacing, Colors} from "../style/allstyles";
import {RoundedSolidButton,NavigatorButton} from "../controls/appbuttons";
import * as StringUtils from "../utils/stringutils";
import * as Constants from "../constants/constants";

export default class GetHelp extends Component {
  render(){
   return (
      <View style={ContainerStyles.pageContainer}>
         <NavigatorButton text="Settings" onPress={()=> this.props.navigation.navigate('ResidentSummary')}></NavigatorButton>
         <View style={{flex:1, 
               flexDirection:"row",
               justifyContent:"flex-start",
               alignItems:"flex-start",
               marginLeft: 0,
               width:"100%"}}>
            <Text style={[Typography.H1, {paddingLeft:16}]}>Get help</Text>
         </View>
         <View style={{flex:1,
               paddingLeft:Spacing.extraLargePad.padding,
               paddingRight:Spacing.extraLargePad.padding,
               width:"100%"}}>
            <View style={{flex:1,
                  borderTopColor: Colors.lightGray,
                  borderTopWidth:1,
                  padding:0,
                  margin:0,
                  width:"100%"}}>
               <Text style={[Typography.label, 
                     {paddingLeft:0, 
                     paddingTop: Spacing.largePad.padding,
                     fontWeight:"normal"}]}>Contact Us</Text>
               <Text>Are you having troubles with the app?</Text>
               <Text 
                  style={[Typography.anchor, Spacing.defaultTopMargin]}
                  onPress={()=>{Linking.openURL("tel://" + Constants.HELPDESK_PHONE)}}>{Constants.HELPDESK_PHONE}</Text>
               <Text 
               style={[Typography.anchor, Spacing.defaultTopMargin]}
                  onPress={()=>{Linking.openURL("mailto:" + Constants.HELPDESK_EMAIL)}}>{Constants.HELPDESK_EMAIL}</Text>
            </View>
         </View>
         <View style={{flex:6}}></View>
         <View style={{flex:2}}>
            <RoundedSolidButton
               onPress={()=> Linking.openURL("tel://" + Constants.HELPDESK_PHONE) }
               cstyle={{width:"94%"}}
               text="Call us"></RoundedSolidButton>
         </View>
         
      </View>
   );
  }
}