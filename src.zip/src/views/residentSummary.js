import React, { PureComponent, Component } from 'react';
import { Text, StyleSheet, View, Image, TouchableOpacity, TouchableHighlight, ScrollView, FlatList } from 'react-native';
import { Dimensions, StatusBar } from 'react-native';
import {AdlApi} from "../api/adl";
import {AuthApi} from "../api/auth";
import { ContainerStyles, ImageStyles, Typography, Colors, Spacing } from '../style/allstyles';
import { SleepIcon , MobilityIcon, VitalsIcon, PersonalHygieneIcon, StatusIcon, NutritionIcon, AvatarIcon } from '../controls/svgIcons';


export class ResidentSummary extends Component {
    // const { navigation } = props;
    constructor(props) {
        super(props);
        this.state = {};
    }
    componentDidMount() {
        AuthApi.isLoggedIn().then((r) =>{
            if(!r) 
                this.props.navigation.navigate("LoginLanding");
            else{
                //get the user summary..
                AdlApi.getUserSummary((data,err) =>{
                    if(data !=null){
                        console.log("Got user data...");
                        console.log(data);
                        this.setState(data);
                    }
                    else
                        alert("Failed to fetch your data. Please try later. If problem persists, reach out to us"); //fixit
                });
            }
        });
    }
    navigateToActivityCharts(activity){
        if(activity=="sleep")
            this.props.navigation.navigate("SleepCharts");
        else if(activity=="mobility")
            this.props.navigation.navigate("MobilityCharts");
        else if(activity =="vitals")
            this.props.navigation.navigate("VitalsCharts");
        else if(activity =="hygiene")
            this.props.navigation.navigate("HygieneCharts");
        else if(activity =="nutrition")
            this.props.navigation.navigate("NutritionCharts");
    }
    getAdlStatusId(adlType) {
        let statusId = "4"; //N/A
        adlType = adlType.trim().toLowerCase();
    
        if (this.state != null && typeof this.state["residents"] !== "undefined") {
          let adls = this.state["residents"][0]["adls"];
          
          //console.log(adls);
          for (let i = 0; i < adls.length; i++) {
            const elm = adls[i];
            if (elm["name"].trim().toLowerCase() == adlType) {
              statusId = elm["statusId"];
              break;
            }
          }
        }
        console.log("adlType=" + adlType + ", statusId=" + statusId);
        return statusId;
      }
      getAdlLastUpdateInfo(adlType) {
        let statusInfo = ""; //N/A
        adlType = adlType.trim().toLowerCase();
    
        if (this.state != null && typeof this.state["residents"] !== "undefined") {
          let adls = this.state["residents"][0]["adls"];
          //console.log(adls);
          for (let i = 0; i < adls.length; i++) {
            const elm = adls[i];
            if (elm["name"].trim().toLowerCase() == adlType) {
              statusInfo = elm["lastUpdateDisplay"];
              break;
            }
          }
        }
        return statusInfo;
      }
    render() {
        console.log('user data:', this.state);
        return (
            <ScrollView style={{backgroundColor:Colors.white}}>
                <View style={ContainerStyles.pageContainer}>
                <View style={[ContainerStyles.bottomShadow,
                            {flex:1, flexDirection:"column",
                            justifyContent:"center",
                            alignItems:"center",
                            paddingBottom: Spacing.largePad.padding,
                            backgroundColor:Colors.white}]}>
                    <Text style={Typography.H1}>My activity</Text>
                    <AvatarIcon></AvatarIcon>
                    <Text onPress={()=>this.props.navigation.navigate("Settings")} 
                        style={Typography.anchor}>Go to profile</Text>
                </View>
                <View style={[ContainerStyles.absPageCenter,
                    {flex:2, 
                        marginTop: Spacing.defaultTopMargin.marginTop,
                        flexDirection:"column", 
                        justifyContent:"center"}]}>
                    <View style={{flex:1, 
                        flexDirection:"row", 
                        width:"100%",
                        justifyContent:"center"}}>
                        {/**Sleep button */}
                        <TouchableOpacity 
                            onPress = {() => this.navigateToActivityCharts("sleep")}
                            style={ContainerStyles.activitySummaryButton}>
                            <StatusIcon 
                                style={ContainerStyles.activityStatusIcon}
                                statusId={this.getAdlStatusId("sleep")}></StatusIcon>
                            <SleepIcon style={ContainerStyles.activityIcon}></SleepIcon>
                            <View style={{flex:1, flexDirection:"column", 
                                        justifyContent:"center",
                                        alignItems:"center", width:"100%"}}>
                                <Text style={Typography.adlName}>Sleep</Text>
                                <Text style={Typography.adlInfo}>{this.getAdlLastUpdateInfo("sleep")}</Text>
                            </View>
                        </TouchableOpacity>
                        {/*Mobility button */}
                        <TouchableOpacity 
                            onPress = {() => this.navigateToActivityCharts("mobility")}
                            style={ContainerStyles.activitySummaryButton}>
                            <StatusIcon 
                                style={ContainerStyles.activityStatusIcon}
                                statusId={this.getAdlStatusId("mobility")}></StatusIcon>
                            <MobilityIcon style={ContainerStyles.activityIcon}></MobilityIcon>
                            <View style={{flex:1, flexDirection:"column", 
                                        justifyContent:"center",
                                        alignItems:"center", width:"100%"}}>
                                <Text style={Typography.adlName}>Mobility</Text>
                                <Text style={Typography.adlInfo}>{this.getAdlLastUpdateInfo("mobility")}</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={{flex:1, 
                        flexDirection:"row", 
                        width:"100%",
                        justifyContent:"center"}}>
                        {/**Vitals button */}
                        <TouchableOpacity 
                            onPress = {() => this.navigateToActivityCharts("vitals")}
                            style={ContainerStyles.activitySummaryButton}>
                            <StatusIcon 
                                style={ContainerStyles.activityStatusIcon}
                                statusId={this.getAdlStatusId("vitals")}></StatusIcon>
                            <VitalsIcon style={ContainerStyles.activityIcon}></VitalsIcon>
                            <View style={{flex:1, flexDirection:"column", 
                                        justifyContent:"center",
                                        alignItems:"center", width:"100%"}}>
                                <Text style={Typography.adlName}>Vitals</Text>
                                <Text style={Typography.adlInfo}>{this.getAdlLastUpdateInfo("vitals")}</Text>
                            </View>
                        </TouchableOpacity>
                        {/*Personla Hygiene button */}
                        <TouchableOpacity 
                            onPress = {() => this.navigateToActivityCharts("hygiene")}
                            style={ContainerStyles.activitySummaryButton}>
                            <StatusIcon 
                                style={ContainerStyles.activityStatusIcon}
                                statusId={this.getAdlStatusId("hygiene")}></StatusIcon>
                            <PersonalHygieneIcon 
                                style={[ContainerStyles.activityIcon, {marginLeft:48}]}></PersonalHygieneIcon>
                            <View style={{flex:1, flexDirection:"column", 
                                        justifyContent:"center",
                                        alignItems:"center", width:"100%"}}>
                                <Text style={Typography.adlName}>Personal Hygiene</Text>
                                <Text style={Typography.adlInfo}>{this.getAdlLastUpdateInfo("hygiene")}</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={{flex:1, 
                        flexDirection:"row", 
                        width:"100%",
                        paddingLeft: 18,
                        justifyContent:"flex-start"}}>
                        {/**Vitals button */}
                        <TouchableOpacity 
                            onPress = {() => this.navigateToActivityCharts("nutrition")}
                            style={ContainerStyles.activitySummaryButton}>
                            <StatusIcon 
                                style={ContainerStyles.activityStatusIcon}
                                statusId={this.getAdlStatusId("nutrition")}></StatusIcon>
                            <NutritionIcon style={ContainerStyles.activityIcon}></NutritionIcon>
                            <View style={{flex:1, flexDirection:"column", 
                                        justifyContent:"center",
                                        alignItems:"center", width:"100%"}}>
                                <Text style={Typography.adlName}>Nutrition</Text>
                                <Text style={Typography.adlInfo}>{this.getAdlLastUpdateInfo("nutrition")}</Text>
                            </View>
                        </TouchableOpacity>
                        {/*Empty section */}
                        
                    </View>
                </View>
            </View>
            </ScrollView>
        );
    }
}

