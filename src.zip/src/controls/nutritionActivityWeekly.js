import React from 'react';
import {StyleSheet, View ,Dimensions} from 'react-native';
import { Svg, G, Line, Rect,XAxis,Text} from 'react-native-svg';
import * as d3 from 'd3';
import {Colors} from "../style/allstyles";
import {DateUtils} from "../utils/dateutils";
import { color } from 'react-native-reanimated';

export class NutritionActivityWeeklyChart extends React.PureComponent{
    constructor(){
        super();
        this.barColors = [Colors.appRed , Colors.blue, Colors.orange , Colors.green, Colors.defaultPurple,
            Colors.darkGray , Colors.darkNavyBlue , Colors.black, Colors.teal , Colors.mediumGray];
    }
    render(){
        
        console.log("NutritionActivityWeeklyChart:Into render...");
        
        let margin = 24;
        let w = Dimensions.get("window").width - margin;
        let data = this.props.chartData;
        let bh = 20;
        let bw = w*0.8;
        
        if( data == null || data["appliances"] == null) return <View></View>;
        
        let colorMap = this.buildApplianceColorMap(data);  
        
        let startEndTimeText = DateUtils.getStartEndTimeText( data["start"], data["end"] );
        
        let displayOrder = DateUtils.getDatesAsWeekdays(
            DateUtils.apiDateToJSDate(data["start"]),
            DateUtils.apiDateToJSDate(data["end"])
        );
        
        let x = this.getXDomain(data,w);
        
        let h = 280 + 50 * this.getCountOfAppliances(data);
        
        return(
            <Svg width={w} height={h} style={{backgroundColor:"white"}}>
                <G transform='translate(0,10)'>
                    <Text key="x1" x='0%' y={0} fontSize='14' fontWeight="bold" fill={Colors.black}>Appliance usage overview</Text>
                    <Text key="x2" x='5%' y={40} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{startEndTimeText["st"]}</Text>
                    <Text key="x3" x='90%' y={40} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{startEndTimeText["et"]}</Text>
                </G>

                <G transform='translate(0,30)'>
                    {
                        this.buildApplianceEvents(displayOrder,data,x,bh,w)
                    }
                </G>
                <G transform='translate(0,260)'>
                    {
                        this.buildApplianceLegend(data)
                    }
                </G>
            </Svg>
        );
    }

    getCountOfAppliances(data){
        let ca = 0;
        console.log("Into getCountOfAppliances:" + data);
        for(idx in data.appliances)
            ca++;
        return ca;
    }
    getXDomain(json,w){
        let startdt = new Date(json["start"]).getTime();
        let enddt = new Date(json["end"]).getTime();

        let x = d3.scaleLinear().domain([startdt , enddt]).range([0,w]);
        return x;
    }
    buildApplianceEvents(displayOrder,data,dx,bh,w){
        let bars=[];
        let colorMap = this.buildApplianceColorMap(data);
        for(idx in displayOrder){
            //console.log("Weekday=" + displayOrder[idx]);
            //The weekday text item
            bars.push(<Text key={"dw_"+idx} x='0%' y={40 + 30*idx} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{displayOrder[idx].substring(0,1)}</Text>);
            //the bar for the weekday
            bars.push(<Rect key={"wdb_"+idx} y={25 + 30*idx} x={20} width={w} height={bh} fill={Colors.superLightGray} />);
            //build event bars...
            let events = this.getWeekdayEvents(data,displayOrder[idx]);
            for(count in events){
                //paint event bar
                let event = events[count];
                //console.log("Event=(appliance,time)=" + event["appliance"] + "," + event["time"]);
                let color = colorMap[event["appliance"]];
                let xpos = dx( DateUtils.apiDateToJSDate(event["time"]) );
                //console.log("AN=" + event["appliance"] + ", xpos=" + xpos + ", color=" + color);
                let eventBar = <Rect key={"aeb_" + event["time"]} 
                            x={xpos} y={25 + 30*idx} height={bh} width={1} fill={color}></Rect>
                bars.push(eventBar);
            }
        }
        return bars;
    }
    buildApplianceLegend(data){
        let colorMap = this.buildApplianceColorMap(data);
        let rows = this.getTotalLegendRows(data);
        let appCount = this.getCountOfAppliances(data);
        let legends = [];
        for(let count=0; count < appCount;){
            let appliance1 = data.appliances[count]["name"];
            let legendColor=colorMap[appliance1];
            let legendRect = null;
            let legendText = null;
            if(count %2 == 0) {
                legendRect= <Rect key={"lc_" + count} x={0} y={10 + (count*20)} width={20} height={20} fill={legendColor} />;
                legendText= <Text key={"ln_" + count} x={30} y={25 + (count*20)} fontSize='14' fontWeight="normal" fill={Colors.black}>{appliance1}</Text>;
            }else{
                legendRect= <Rect key={"lc_" + count} x={150} y={10 + ((count-1)*20)} width={20} height={20} fill={legendColor} />;
                legendText= <Text key={"ln_" + count} x={180} y={25 + ((count-1)*20)} fontSize='14' fontWeight="normal" fill={Colors.black}>{appliance1}</Text>;
            }
            //console.log(legendRect);
            legends.push(legendRect);
            legends.push(legendText);
            count++;
        }
        return legends;
    }
    getApplianceEventDomainAndRange(data,w){
        let startdt = new Date(data["start"]).getTime();
        let enddt = new Date(data["end"]).getTime();

        let x = d3.scaleLinear().domain([startdt , enddt]).range([0,w])
        return x;
    }
    getWeekdayEvents(data,wd){
        for(idx in data.days){
            let day = data.days[idx];
            if(day.dayName == wd){
                return day["events"];
            }
        }
        return null;
    }
    buildApplianceColorMap(data){
        let colorMap = {};
        let appCount = this.getCountOfAppliances(data);
        
        for(let idx=0; idx < appCount; idx++){
            let appliance = data.appliances[idx];
            let aName = appliance["name"];
            let color = (idx >= this.barColors.length) ? this.barColors[ idx - this.barColors.length ] : this.barColors[idx];
            colorMap[aName] = color;
            console.log(aName + "=" + color);
        }
        //console.log("Color map=" + colorMap);
        return colorMap;
    }
    getTotalLegendRows(data){
        let appCount = this.getCountOfAppliances(data);
        if(appCount % 2 == 0)
            return (appCount/2);
        else
        return ((appCount/2) + 1);
    }
}
