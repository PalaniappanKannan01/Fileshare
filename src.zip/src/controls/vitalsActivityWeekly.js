import React from 'react';
import {StyleSheet, View ,Dimensions} from 'react-native';
import { Svg, G, Line, Rect,Circle,Text,Path} from 'react-native-svg';
import * as d3 from 'd3';
import {Colors} from "../style/allstyles";
import {DateUtils} from "../utils/dateutils";

export class VitalsActivityWeeklyChart extends React.PureComponent{
    
    render(){
        console.log("VitalsActivityWeeklyChart:Into render...["+this.props.type+"]");
        let margin = 24;
        let w = Dimensions.get("window").width - margin;
        let h = 300;
        let gu = 10;
        let data = this.props.chartData;
        let type = this.props.type;

        if( data == null || data["days"] == null ) return <View></View>;
        let y = this.getDomainAndRangeY(data,type,h - 80);
        let x = this.getDomainAndRangeX(data, w);
        let legendText = (type=="hr") ? "resting heart rate" : "respiratory rate";
        let maxY = this.getMaxY(data,type);
        let weekdays = DateUtils.getDatesAsWeekdays(
            DateUtils.apiDateToJSDate(data["start"]),
            DateUtils.apiDateToJSDate(data["end"])
        );
        
        //console.log("drawPath=" + this.drawPath(data,type,x,y));
        return(
            <Svg width={w} height={h} style={{}}>
                <G transform='translate(0,0)'>
                    <Text x='95%' y={10} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{maxY}</Text>
                    <Line x1={0} y1={12} x2={w} y2={10} stroke={Colors.lightGray}></Line>
                    <Text x='95%' y={120} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{maxY/2}</Text>
                    <Line x1={0} y1={120} x2={w} y2={120} stroke={Colors.lightGray}></Line>

                    <Line x1={0} y1={h-70} x2={w} y2={h-70} stroke={Colors.lightGray}></Line>
                    <Path d={this.drawPath(data,type,x,y)} 
                                fill="transparent" 
                                strokeWidth={2}
                                stroke={Colors.vinyaDefaultColor}></Path>
                    {
                        weekdays.map((wd,idx) => {
                            let wdData = this.getWeekdayRecord(data,wd);
                            let xpos = x(DateUtils.apiDateToJSDate(wdData["time"]).getTime());
                            let ypos = y(wdData[type]);
                            return (
                                <G key={"gk_" + idx}>
                                    <Text key={"wd_" + idx} x={(idx) * 50} y={h-50} fontSize='12' fontWeight="normal" fill={Colors.mediumGray}>{wd.substring(0,3)}</Text>
                                    <Circle key={"p_" + idx} cx={xpos} cy={ypos} r="4" stroke={Colors.vinyaDefaultColor} strokeWidth={2} fill="white" ></Circle>
                                </G>
                            );
                        })
                    }
                    
                </G>
                {/*
                <G transform='translate(0,280)'>
                    <Line x1={0} y1={12} x2={60} y2={12} strokeWidth={2} stroke={Colors.vinyaDefaultColor}></Line>
                    <Text x={80} y={15} fontSize='12' fill={Colors.mediumGray}>
                        {legendText}
                    </Text>
                </G>*/}
            </Svg>
        );
    }
    getMaxY(data,sel){
        let readings = data["days"];
        let maxY = Number.MIN_SAFE_INTEGER;
        for(let idx=0; idx < readings.length; idx++){
            let value = readings[idx][sel];
            if(value !=null){
                value = Math.ceil(value);
                if(value > maxY) maxY = value;
            }
        }
        console.log("Max Y=" + maxY);
        return maxY;
    }
    getWeekdayRecord(data,wd){
        let days = data["days"];
        let wdNames=DateUtils.getWeekdayNames();
        for(let idx=0; idx < days.length; idx++){
            let theDay = days[idx];
            let date = DateUtils.apiDateToJSDate(theDay["time"]);
            if(wdNames[date.getDay()]==wd){
                return theDay;
            }
        }
        return null;
    }
    drawPath(data,sel,xd,yd){
        console.log("Into drawPath...");
        let cmd="";
        let addedMove = false;
        let days = data["days"];
        for(let idx=0; idx < days.length; idx++){
            let wd = days[idx];
            if(!addedMove){ 
                cmd = "M " ;
                addedMove = true;
            }else
                cmd += " L " ;
            let wdate = DateUtils.apiDateToJSDate(wd["time"]);
            let xval = wdate.getTime();
            let yval = wd[sel];
            if(yval ==null) yval = 0;
            console.log("WDate=" + wdate +" , X=" + xd(xval) + ", Y=" + yd(yval));
            cmd +=xd(xval) + " " + yd(yval) ; 
        }
        //console.log("Path=" + cmd);
        return cmd;
    }
    getDomainAndRangeX(data,w){
        let startDt = DateUtils.apiDateToJSDate(data["start"]);
        let endDt = DateUtils.apiDateToJSDate(data["end"]);
        let x = d3.scaleLinear().domain([startDt.getTime(),endDt.getTime()]).range([0,w]);
        return x;
    }
    getDomainAndRangeY(data, sel,h){
        let readings = data["days"];
        let min = Number.MAX_SAFE_INTEGER;
        let max = Number.MIN_SAFE_INTEGER;
        for(let idx=0;idx < readings.length; idx++){
            let reading = readings[idx];
            let value = reading[sel];
            if(value !=null){
                if(value > max) max = value;
                if(value < min) min = value;
            }
        }
        //create the domain and range
        console.log("Domain Y==[" + min + "," + max +"]" );
        let y = d3.scaleLinear().domain([min,max]).range([0,h]);
        return y;
    }
}
