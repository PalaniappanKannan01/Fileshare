import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import {Colors} from "../style/allstyles";
import * as Constants from "../constants/constants";
import DateUtils from "../utils/dateutils";
import {NavigatorNoTextButton} from "../controls/appbuttons";

export const DayRangeScroller = (props)=>{
    //let currStartDate = DateUtils.reformat_1(startDt);
    return(
        <View style={{flex:1, 
            flexDirection:"row",
            alignItems:"center",
            justifyContent:"space-between"}}>
        <NavigatorNoTextButton onPress={()=> props.onPrev()}></NavigatorNoTextButton>
        <Text style={{color:Colors.darkGray}}>{props.timePeriodLabel}</Text>
        <NavigatorNoTextButton dir="right" onPress={()=>props.onNext()}></NavigatorNoTextButton>
        </View>
    );
};
