import React from 'react';
import {StyleSheet, View ,Dimensions} from 'react-native';
import { Svg, G, Line, Rect,XAxis,Text} from 'react-native-svg';
import * as d3 from 'd3';
import {Colors} from "../style/allstyles";
import {DateUtils} from "../utils/dateutils";

export class MobilityActivity24HrChart extends React.PureComponent{
    
    render(){
        console.log("MobilityActivity24HrChart:Into render...");
        let margin = 24;
        let w = Dimensions.get("window").width - margin;
        let m = (w/2 - 20) + "";
        let e = (w - 100)+"";
        let bh = 28;
        let gu = 10;
        let bm=10;
        let legendW=16;
        let data = this.props.chartData;

        if( data == null || data["rooms"] == null ) return <View></View>;
        
        let x = this.getDomainAndRange(data,w);
        let roomNames = this.getRoomNames(data);
        let startEndTimeText = DateUtils.getStartEndTimeText( data["start"], data["end"] );
        let yposlst=[0,80,160,240];
        return(
            <Svg width={w} height={300}>
                {   
                    <G key={"g_Start"} transform={"translate(0,20)"}>
                        {
                            roomNames.map((rn,idx) => {
                                return(
                                    <G key={"g_"+idx} width={100}>
                                        <Text key={"rn_" + idx} x='0' y={yposlst[idx]} fontSize='14' fontWeight="bold" fill={Colors.black}>{rn}</Text>
                                        <Text key={"rt_" + idx} x='65%' y={yposlst[idx]} fontSize='14' fontWeight="normal" fill={Colors.black}>{this.getRoomTimeTotal(data,rn)}</Text>
                                        <Rect key={"rb_" + idx} x={0} y={yposlst[idx]+4} width={w} height={bh} fill={Colors.superLightGray} />
                                        {this.buildRoomEventDataBars(data,rn,x,bh,w,yposlst[idx]+4)}
                                        <Text key={rn+"_st"+idx} x='0%' y={yposlst[idx] + 50} fontSize='14' fontWeight="normal" fill={Colors.darkGray}>{startEndTimeText["st"]}</Text>
                                        <Text key={rn+"_et"+idx} x='90%' y={yposlst[idx] + 50} fontSize='14' fontWeight="normal" fill={Colors.darkGray}>{startEndTimeText["et"]}</Text>
                                        
                                    </G>
                                );
                            })
                        }
                    </G>
                }
            </Svg>
        );
    }
    getRoomNames(data){
        let rooms = data["rooms"];
        let roomNames=[];
        for(let idx=0; idx < rooms.length;idx++)
            roomNames.push( rooms[idx]["name"] );
        return roomNames;
    }
    
    buildRoomEventDataBars(data,sel,dx,bh,w,ypos){
        console.log("Building data bars for room =" + sel +" , canvas width=" + w);
        try{
            let rooms = data["rooms"];
            let minX = dx(new Date(Date.parse(data["start"])));
            let maxX = dx(new Date(Date.parse(data["end"])));
            let bars = [];
            for(let i=0; i < rooms.length; i++){
                let room = rooms[i];
                if(room["name"]==sel){
                    let events = room["events"];
                    console.log("Room=" + sel +" , Events=" + events.length);
                    //build all bars...
                    for(let idx=0; idx < events.length; idx++){
                        let elm = events[idx];
                        try{
                            let startX = dx(DateUtils.apiDateToJSDate(elm["start"]));
                            let endX = dx(DateUtils.apiDateToJSDate(elm["end"]));
                            
                            while(endX > w) /**since data is not correct */
                                endX -= 0.5;
                            let barW = (endX - startX);
                            
                            //console.log(sel + " ::startX diff=" + (startX - minX) + " , endX Diff=" + (maxX - endX) + ", W=" + barW);
                            console.log(sel + " ::startX =" + (startX) + " , endX =" + (endX) + ", barW=" + barW);
                            //let rect = <Rect key={"redb_" + sel + "_" + idx} y={ypos} x={0} width={barW} height={bh} fill={Colors.vinyaDefaultColor} />;
                            let rect = <Rect key={"redb_" + sel + "_" + idx} y={ypos} x={startX} width={1} height={bh} fill={Colors.vinyaDefaultColor} />;
                            //console.log("Room Name=" + sel + "->"+rect);
                            bars.push (rect);
                        }catch(err){
                            console.warn(err);
                        }
                    }
                }
            }
            return bars;
        }catch(e){
            console.warn(e);
        }
    }
    
    getDomainAndRange(data,width){
        let startDt = new Date(Date.parse(data["start"]));
        let endDt = new Date(Date.parse(data["end"]));
        console.log("getDomainAndRange:[" + startDt + "," + endDt + "]")
        let x = d3.scaleLinear().domain([startDt,endDt]).range([0,width]);
        return x;
    }
    
    getRoomTimeTotal(data,rm){
        let rooms = data["rooms"];
        //console.log("Rooms length=" + rooms.length);
        for(let i=0; i < rooms.length; i++){
            let elm = rooms[i];
            if(elm["name"] == rm){
                console.log("Room =" + rm + " , Total Time=" + elm["total"]);
                return  elm["total"];
            }
        }
        return 0;
    }
}
