import React, {Component} from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import Icon from 'react-native-vector-icons/AntDesign';
import {
  Colors,
  Spacing,
  Typography,
} from "../style/allstyles";

export default class AppText extends Component {
    render(){
        return (<Text {...this.props} style={{fontSize:18}}>{this.props.children}</Text>);
    }
};