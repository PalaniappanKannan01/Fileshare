import React from 'react';
import {StyleSheet, View ,Dimensions} from 'react-native';
import { Svg, G, Line, Rect,XAxis,Text} from 'react-native-svg';
import * as d3 from 'd3';
import {Colors} from "../style/allstyles";
import {DateUtils} from "../utils/dateutils";
import * as Constants from "../constants/constants";

export class SleepActivity24HrChart extends React.PureComponent{
    
    render(){
        console.log("SleepActivity24HrChart:Into render...");
        let margin = 24;
        let w = Dimensions.get("window").width - margin;
        let m = (w/2 - 20) + "";
        let e = (w - 38)+"";
        let bh = 48;
        let gu = 10;
        let bm=10;
        let legendW=16;
        let data = this.props.chartData;

        if( data == null || data["classes"] == null ) return <View></View>;
        let ax = this.getDomainAndRange(data,"Awake",w);
        let lx = this.getDomainAndRange(data,"Light",w);
        let dx = this.getDomainAndRange(data,"Deep",w);
        let rx = this.getDomainAndRange(data,"REM",w);
        return(
            <Svg width={w} height={w} style={{}}>
                <G transform='translate(0,12)'>
                    <Text x='0' fontSize='14' fill={Colors.mediumGray}>12PM</Text>
                    <Text x={m} fontSize='14' fill={Colors.mediumGray}>12AM</Text>
                    <Text x={e} fontSize='14' fill={Colors.mediumGray}>12PM</Text>
                </G>
                <G transform="translate(0,20)">
                    <Rect x={0} width={w} height={bh} fill={Colors.superLightGray} />
                    {/*Paint values for Awake series*/}
                    {
                        data["classes"]["Awake"].map((elm,idx) =>{
                            if(ax != null){
                                let startX = ax(DateUtils.apiDateToJSDate(elm["start"]));
                                let endX = ax(DateUtils.apiDateToJSDate(elm["end"]));
                                let barW = Math.ceil(endX - startX);
                                console.log("Awake ::startX=" + startX + " , endX=" + endX + ", W=" + barW);
                                return (<Rect key={elm["start"]}  x={startX} width={barW} height={bh} fill={Colors.teal} />);
                            }else{
                                return (<Rect key={elm["start"]} x={0} w={0}/>);
                            }
                        })
                    }
                </G>
                <G transform="translate(0,72)">
                    <Rect x={0} width={w} height={bh} fill={Colors.superLightGray} />
                    {/*Paint values for Light series*/}
                    {
                        data["classes"]["Light"].map((elm,idx) =>{
                            if(ax != null){
                                let startX = lx(DateUtils.apiDateToJSDate(elm["start"]));
                                let endX = lx(DateUtils.apiDateToJSDate(elm["end"]));
                                let barW = Math.ceil(endX - startX);
                                console.log("Light ::startX=" + startX + " , endX=" + endX + ", W=" + barW);
                                return (<Rect key={elm["start"]}  x={startX} width={barW} height={bh} fill={Colors.orange} />);
                            }else{
                                return (<Rect key={elm["start"]} x={0} w={0}/>);
                            }
                        })
                    }
                </G>
                <G transform="translate(0,124)">
                    <Rect x={0} width={w} height={bh} fill={Colors.superLightGray} />
                    {/*Paint values for Deep series*/}
                    {
                        data["classes"]["Deep"].map((elm,idx) =>{
                            if(ax != null){
                                let startX = dx(DateUtils.apiDateToJSDate(elm["start"]));
                                let endX = dx(DateUtils.apiDateToJSDate(elm["end"]));
                                let barW = Math.ceil(endX - startX);
                                console.log("Deep ::startX=" + startX + " , endX=" + endX + ", W=" + barW);
                                return (<Rect key={elm["start"]}  x={startX} width={barW} height={bh} fill={Colors.darkNavyBlue} />);
                            }else{
                                return (<Rect key={elm["start"]} x={0} w={0}/>);
                            }
                        })
                    }
                </G>
                <G transform="translate(0,176)">
                    <Rect x={0} width={w} height={bh} fill={Colors.superLightGray} />
                    {/*Paint values for REM series*/}
                    {
                        data["classes"]["REM"].map((elm,idx) =>{
                            if(ax != null){
                                let startX = rx(DateUtils.apiDateToJSDate(elm["start"]));
                                let endX = rx(DateUtils.apiDateToJSDate(elm["end"]));
                                let barW = Math.ceil(endX - startX);
                                console.log("REM ::startX=" + startX + " , endX=" + endX + ", W=" + barW);
                                return (<Rect key={elm["start"]}  x={startX} width={barW} height={bh} fill={Colors.appRed} />);
                            }else{
                                return (<Rect key={elm["start"]} x={0} w={0}/>);
                            }
                        })
                    }
                </G>
                <G transform='translate(0,240)'>
                    <Rect x={0} width={legendW} height={legendW} fill={Colors.teal}/>
                    <Text x={gu+legendW} y={12} fontSize='14' fill={Colors.mediumGray}>Awake</Text>
                    
                    <Rect x={5*legendW+bm} width={legendW} height={legendW} fill={Colors.orange} />
                    <Text x={gu + 6.5*legendW} y={12} fontSize='14' fill={Colors.mediumGray}>Light</Text>

                    <Rect x={10*legendW+bm} width={legendW} height={legendW} fill={Colors.darkNavyBlue} />
                    <Text x={11.5*legendW + bm} y={12} fontSize='14' fill={Colors.mediumGray}>Deep</Text>

                    <Rect x={15*legendW+bm} width={legendW} height={legendW} fill={Colors.appRed} />
                    <Text x={16.5*legendW + bm} y={12} fontSize='14' fill={Colors.mediumGray}>REM</Text>
                </G>
            </Svg>
        );
    }
    getDomainAndRange(data, sel,w){
        let series = data["classes"][sel];
        let x = null;
        if(series.length > 0){
            /* Compute domain.. */
            let startDt = new Date( Date.parse(data["start"]) );
            let endDt = new Date( Date.parse(data["end"] ));
            console.log("DOMAIN [" + sel + "] ::StartDt=" + startDt + " , endDt=" + endDt);
            x = d3.scaleLinear().domain([startDt , endDt]).range([0 , w]);
            return x;
        }
        return null;
    }
}
