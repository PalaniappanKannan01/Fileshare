import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import {Colors} from "../style/allstyles";
import * as Constants from "../constants/constants";

export const ChartDataSummary = (props)=>{
    //console.log("value=" + props.valueText);
    return(
        <View style={{borderWidth:0, 
            backgroundColor:Colors.superLightGray, 
            marginLeft:12,
            marginRight:12,
            padding:12,
            borderRadius:8,
            height:96,
            flexDirection:"column",
            justifyContent:"space-between",
            alignItems:"flex-start"}}>
        <Text>{props.headerText}</Text>
        <Text style={{fontSize:32, fontWeight:"bold"}}>{props.valueText}</Text>
        <Text>{props.footerText}</Text>
      </View>
    );
};