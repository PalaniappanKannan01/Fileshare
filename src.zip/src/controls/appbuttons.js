import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import Icon from 'react-native-vector-icons/AntDesign';
import {
  Colors,
  Spacing,
  Typography,
} from "../style/allstyles";

export const RoundedSolidButton = ({ onPress, text, bstyle, cstyle }) => (
  <TouchableOpacity activeOpacity={0.8} onPress={onPress} style={{ ...bstyle }}>
    <View style={[styles.roundedButtonContainer, cstyle]}>
      <Text style={styles.roundedButtonText}>{text}</Text>
    </View>
  </TouchableOpacity>
);

export const RoundedBorderButton = ({ onPress, text, bstyle, cstyle }) => (
  <TouchableOpacity activeOpacity={0.8} onPress={onPress} style={{ ...bstyle }}>
    <View style={[styles.roundedBorderButtonContainer, cstyle]}>
      <Text style={styles.roundedBorderButtonText}>{text}</Text>
    </View>
  </TouchableOpacity>
);

export const NavigatorButton = ({onPress , text}) => (
    <View style={{paddingLeft:10}}>
      <TouchableOpacity activeOpacity = {0.8}>
        <Icon.Button name="left" backgroundColor="transparent" color={Colors.darkGray} size={15} 
          onPress={onPress}>
            <Text>{text}</Text>
        </Icon.Button>
      </TouchableOpacity>
    </View>
);

export const NavigatorNoTextButton = ({onPress , dir}) => {
  let iconName = (typeof dir !== "undefined") ? dir : "left";
  return (
  <View style={{paddingLeft:10}}>
    <TouchableOpacity activeOpacity = {0.8}>
      <Icon.Button name={iconName} backgroundColor="transparent" color={Colors.darkGray} size={15} 
        onPress={onPress}>
      </Icon.Button>
    </TouchableOpacity>
  </View>);
}

const styles = StyleSheet.create( {
  roundedButtonContainer :{
    elevation: 0,
    backgroundColor: Colors.vinyaDefaultColor,
    borderRadius: 30,
    paddingVertical: 14,
    paddingHorizontal: 12,
    margin: 12,
    width: "90%",
    height: 48,
  },

  roundedButtonText : {
    color: Colors.white,
    fontWeight: "bold",
    textAlign: "center",
  },
  
  roundedBorderButtonContainer :{
    elevation: 0,
    borderWidth: 1,
    borderColor: Colors.vinyaDefaultColor,
    borderRadius: 30,
    paddingVertical: 14,
    paddingHorizontal: 12,
    margin: 12,
    width: "90%",
    height: 48,
  },
  roundedBorderButtonText : {
    color: Colors.vinyaDefaultColor,
    fontWeight: "bold",
    textAlign: "center",
  },
});
