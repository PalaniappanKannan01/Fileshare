import React, {Component} from "react";
import { Image } from "react-native";
import {Colors , ImageStyles} from "../style/allstyles";
import * as Constants from "../constants/constants";
import {DateUtils} from "../utils/dateutils";
import {AdlApi} from "../api/adl";

export class Avatar extends Component{
    
    constructor(){
        super();
        this.fallbackUrl = "../assets/images/generic_user.jpg";
        this.state = {url:this.fallbackUrl};
    }
    
    render(){
            <Image  url={this.state.url} 
                style={[ImageStyles.profileAvatar, {width:96,height:96}]}/> ;
    }
    
}
