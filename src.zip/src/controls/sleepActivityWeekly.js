import React from 'react';
import {StyleSheet, View ,Dimensions} from 'react-native';
import { Svg, G, Line, Rect,XAxis,Text} from 'react-native-svg';
import * as d3 from 'd3';
import {Colors} from "../style/allstyles";
import {DateUtils} from "../utils/dateutils";
import * as StringUtils from "../utils/stringutils";
import * as Constants from "../constants/constants";

export class SleepActivityWeeklyChart extends React.PureComponent{
    
    render(){
        console.log("SleepActivityWeeklyChart:Into render...");
        let margin = 24;
        let w = Dimensions.get("window").width - margin;
        let bh = 24;
        let bandGap=28;
        let data = this.props.chartData;

        if( data == null || data["days"] == null ) return <View></View>;
        
        let displayOrder = DateUtils.getDatesAsWeekdays(
            DateUtils.apiDateToJSDate(data["start"]),
            DateUtils.apiDateToJSDate(data["end"])
        );
        
        return(
            <Svg width={w} height={w} style={{}}>
                <G transform="translate(0,15)">
                    <Text x={"24"} y={0} fontSize='14' fill={Colors.mediumGray}>12AM</Text>
                    <Text x={"90%"} y={0} fontSize='14' fill={Colors.mediumGray}>12AM</Text>
                </G>
                {
                    displayOrder.map( (wd , idx) =>{
                        return(
                            <G key={"g_"+idx} transform={"translate(0," + ((idx+1) * bandGap) + ")"}>
                                <Text key={"wd_"+idx} x={0} y={16} fontSize='14' fill={Colors.mediumGray}>{ wd.substring(0,1) }</Text>
                                <Rect key={"wdb_"+idx} x={24} y={0} width={w} height={bh} fill={Colors.superLightGray} />
                                {/**Friday... */}
                                {
                                    /**have to copy paste here...! */
                                    this.getWeekdaySessions(data,wd).map((elm,idx) =>{
                                        let dr = this.getDomainAndRange(data , wd , w);
                                        if(dr != null){
                                            console.log("Rendering for " + wd +"...");
                                            let startX = dr(DateUtils.apiDateToJSDate(elm["start"])) + 24;
                                            let endX = dr(DateUtils.apiDateToJSDate(elm["end"]));
                                            //console.log(sel + "|| " + endX);
                                            if(endX > w) /**since data is not correct */
                                                endX = w;
                                            let barW = Math.ceil(endX - startX);
                                            console.log(wd + " ::startX=" + startX + " , endX=" + endX + ", W=" + barW);
                                            let rect = <Rect key={"wdu_"+idx} y={0}  x={startX} width={barW} height={bh} fill={Colors.vinyaDefaultColor} />;
                                            //console.log(rect);
                                            return rect;
                                        }else{
                                            return (<Rect key={"wdu_"+idx} y={0} x={24} w={0}/>);
                                        }
                                    })
                                }
                            </G>
                        );
                    } )
                }
                
            </Svg>
        );
    }
    
    getWeekdaySessions(data,sel){
        let weekdays = data["days"];
        for(let i=0; i < weekdays.length; i++){
            let wday = weekdays[i];
            if(wday["dayName"]==sel){
                let sessions = wday["sessions"];
                return sessions; 
            }
        }
        return null;
    }
    getDomainAndRange(data,sel, width){
        //console.log("Into getDomainAndRange[" + sel + "]...");
        let weekdays = data["days"]; 
        
        if(weekdays !=null && weekdays.length > 0){
            //the sessions are recorded from 12am to 12am..
            let dateRange =null;
            for(let idx=0; idx < weekdays.length; idx++){
                let day = weekdays[idx];
                if(day["dayName"]==sel){
                    dateRange = this.getMinMaxSessionDates(data,sel);
                    if(dateRange !=null){
                        //console.log("Label=" + dateRange.label + ", Start=" + dateRange.min + ", End=" + dateRange.max);
                        break;
                    }
                }
            }
            /*We now have the date[day]...the whole day is the domain */
            /** create domain and range*/
            if(dateRange !=null){
                console.log("getDomainAndRange::" + sel + ", dateLabel=" +dateRange.label
                    + ", min=" + dateRange.min + ", max=" + dateRange.max + ", w=" + width);
                
                let x = d3.scaleLinear().domain([dateRange.min.getTime(),dateRange.max.getTime()]).range([0,width]);
                return x;
            }
        }
        return null;
    }
    //fixit...
    /** 
     * For a given date label, the session starts 12AM of that date to 12AM of the end date
    */
    getMinMaxSessionDates(data,sel){
        let days = data["days"];
        let tz="";
        for(let idx=0;idx < days.length; idx++){
            let day = days[idx];
            if(day["dayName"]==sel){
                //for this day..the recordings starts from 12 midnight...
                //and ends on the next day at 12 midnight
                let dateLabel = day["dateLabel"];
                let minSessionDt = new Date(Date.parse(day["periodStart"]));
                let maxSessionDt = new Date(Date.parse(day["periodEnd"]));
                return {label: dateLabel, min : minSessionDt , max : maxSessionDt};
            }
        }
        return null;
    }
}
