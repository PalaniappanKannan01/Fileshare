import React from 'react';
import {StyleSheet, View ,Dimensions} from 'react-native';
import { Svg, G, Line, Rect,XAxis,Text} from 'react-native-svg';
import * as d3 from 'd3';
import {Colors} from "../style/allstyles";
import {DateUtils} from "../utils/dateutils";
import { color } from 'react-native-reanimated';

export class NutritionActivity24HrChart extends React.PureComponent{
    constructor(){
        super();
        this.barColors = [Colors.appRed , Colors.blue, Colors.orange , Colors.green, Colors.defaultPurple,
            Colors.darkGray , Colors.darkNavyBlue , Colors.black, Colors.teal , Colors.mediumGray];
    }
    render(){
        console.log("NutritionActivity24HrChart:Into render...");
        let margin = 24;
        let w = Dimensions.get("window").width - margin;
        let data = this.props.chartData;
        let abh = 20;
        let abw = w*0.8;
        if( data == null ) return <View></View>;
        let h = 150 + 50 * this.getCountOfAllApplianceUsage(data);
        
        let colorMap = this.buildApplianceColorMap(data);     
                  
        let ux = this.getApplianceUsageDomainAndRange(data,abw);
        let ex = this.getApplianceEventDomainAndRange(data,w);
        
        return(
            <Svg width={w} height={330} style={{backgroundColor:"white"}}>
                <G transform='translate(0,10)'>
                    <Text key="x1" x='0' fontSize='14' fontWeight="bold" fill={Colors.black}>Appliance usage overview</Text>
                    <Text key="x2" x='65%' fontSize='14' fontWeight="normal" fill={Colors.black}>{this.getCountOfAllApplianceUsage(data)} times</Text>
                    
                </G>

                <G transform='translate(0,10)'>
                    <G transform='translate(0,10)'>
                        <Rect key={new Date().getTime().toString()} 
                                x={0} y={0} height={80} width={w} fill={Colors.superLightGray}></Rect> 
                                
                        {this.buildApplianceUseEventBars(data,ex,w,80)}
                        <Line x1='0%' x2='100%' y1={90} y2={90} stroke={Colors.lightGray}></Line>   
                    </G>
                    <G transform='translate(0,100)'>
                        <Text key="x1" x='0' y={20} fontSize='14' fontWeight="bold" fill={Colors.black}>Distribution of appliance usage</Text>
                        {this.buildApplianceTotalUsageBars(data,ux,abw,abh)}
                    </G>
                    
                </G>
            </Svg>
        );
    }
    getCountOfAppliances(data){
        let ca = 0;
        for(idx in data.appliances)
            ca++;
        return ca;
    }
    getCountOfAllApplianceUsage(data){
        let appCount = this.getCountOfAppliances(data);
        let usageCount=0;
        for(let idx=0; idx < appCount; idx++)
            usageCount += data.appliances[idx]["uses"];
        return usageCount;
    }
    getApplianceUsageDomainAndRange(data,w){
        let maxUse = Number.MIN_SAFE_INTEGER;

        for(appIdx in data.appliances){
            let usage = data["appliances"][appIdx]["uses"];
            //console.log("appliance idx=" + appIdx + ", usage=" + usage);
            if(usage > maxUse) maxUse = usage;
        }
        //console.log("building domain/range=...max=" + maxUse + ", range max=" + w);
        let x = d3.scaleLinear().domain([0 , maxUse]).range([0,w]);
        return x;
    }
    getApplianceEventDomainAndRange(data,w){
        let startdt = new Date(data["start"]).getTime();
        let enddt = new Date(data["end"]).getTime();

        let x = d3.scaleLinear().domain([startdt , enddt]).range([0,w])
        return x;
    }
    buildApplianceUseEventBars(data,dx,w,abh){
        let bars = [];
        let colorMap = this.buildApplianceColorMap(data);
        for(eIdx in data.events){
            let event = data.events[eIdx];
            let color = colorMap[data,event["appliance"]];
            let xpos = dx( DateUtils.apiDateToJSDate(event["time"]) );
            //console.log("AN=" + event["appliance"] + ", xpos=" + xpos + ", color=" + color);
            let eventBar = <Rect key={"ae_" + eIdx} 
                            x={xpos} y={0} height={80} width={1} fill={color}></Rect>
            bars.push(eventBar);
        }
        return bars;
    }
    
    buildApplianceTotalUsageBars(data,dx,w , abh){
        let bars=[];
        let textYOffset = 50;
        let colorMap = this.buildApplianceColorMap(data);
        for(appIdx in data.appliances){
            let appliance = data["appliances"][appIdx];
            console.log("Building appliance bar for:" + appliance["name"]);
            //build appliance name text
            let text = <Text key={appliance["name"] + "_nm"} x='0' y={40 + appIdx * textYOffset} 
                    fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{appliance["name"]}</Text>;
            console.log("Appliance=" + appliance["name"] + " , " + appliance["uses"]);
            //build appliance bar
            let barWidth = dx(appliance["uses"]);
            let barColor = colorMap[data,appliance["name"]];
            let bar = <Rect key={appliance["name"] + "_br"}  
                    x={0} y={44 + (appIdx*50)} height={abh} width={barWidth} fill={barColor}></Rect>
            //build text to show use
            let useText = <Text key={appliance["name"] + "_ut"}  
                            x={w + 10} y={44 + (appIdx*50) + 15} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{appliance["uses"]}</Text>;
            //console.log(bar);
            bars.push(text);
            bars.push(bar);
            bars.push(useText);
        }
        return bars;
    }
    buildApplianceColorMap(data){
        let colorMap = {};
        let appCount = this.getCountOfAppliances(data);
        
        for(let idx=0; idx < appCount; idx++){
            let appliance = data.appliances[idx];
            let aName = appliance["name"];
            let color = (idx >= this.barColors.length) ? this.barColors[ idx - this.barColors.length ] : this.barColors[idx];
            colorMap[aName] = color;
            //.log(aName + "=" + color);
        }
        //console.log("Color map=" + colorMap);
        return colorMap;
    }
    
}
