import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import {Colors} from "../style/allstyles";
import * as Constants from "../constants/constants";
import {DateUtils} from "../utils/dateutils";

export const DayRangePicker = (props , onChange)=>{
    //console.log("DayRangePicker::tsfilter=" + props.tsfilter);
    let dayBgColor = (props.tsfilter == Constants.ActivityDataFilters.day) ? Colors.vinyaDefaultColor : Colors.white;
    let weekBgColor= (props.tsfilter == Constants.ActivityDataFilters.week) ? Colors.vinyaDefaultColor : Colors.white;
    let monthBgColor=(props.tsfilter == Constants.ActivityDataFilters.month) ? Colors.vinyaDefaultColor : Colors.white;
    let yearBgColor=(props.tsfilter == Constants.ActivityDataFilters.year) ? Colors.vinyaDefaultColor : Colors.white;

    let dayFontColor = (props.tsfilter == Constants.ActivityDataFilters.day) ? Colors.white : Colors.black;
    let weekFontColor = (props.tsfilter == Constants.ActivityDataFilters.week) ? Colors.white : Colors.black;
    let monthFontColor = (props.tsfilter == Constants.ActivityDataFilters.month) ? Colors.white : Colors.black;
    let yearFontColor = (props.tsfilter == Constants.ActivityDataFilters.year) ? Colors.white : Colors.black;

    let dayFontWeight = (props.tsfilter == Constants.ActivityDataFilters.day) ? "bold" : "normal";
    let weekFontWeight = (props.tsfilter == Constants.ActivityDataFilters.week) ? "bold" : "normal";
    let monthFontWeight = (props.tsfilter == Constants.ActivityDataFilters.month) ? "bold" : "normal";
    let yearFontWeight = (props.tsfilter == Constants.ActivityDataFilters.year) ? "bold" : "normal";

    return(<View style={{borderWidth:1, 
        borderColor:"#ababab", 
        margin:12,
        paddingLeft:2,
        paddingRight:4,
        borderRadius:8,
        height:42,
        flexDirection:"row",
        justifyContent:"space-between",
        alignItems:"center"}}>
        <TouchableOpacity style={{width:"45%", height:"100%"}} onPress={()=> props.onChange(Constants.ActivityDataFilters.day)}>
            <View style={{borderWidth:0,  
                        justifyContent:"center",
                        alignItems:"center",
                        margin:2,
                        padding:2,
                        borderRadius:8,
                        height:"92%",
                        width:"100%",
                        backgroundColor: dayBgColor}}>
            <Text style={{fontSize:14, fontWeight:dayFontWeight,color:dayFontColor}}>24h</Text>
            </View>
        </TouchableOpacity>
        <TouchableOpacity style={{width:"45%", height:"100%"}} onPress={()=> props.onChange(Constants.ActivityDataFilters.week) }>
            <View style={{borderWidth:0,  
                        justifyContent:"center",
                        alignItems:"center",
                        margin:2,
                        marginRight:5,
                        padding:2,
                        borderRadius:8,
                        height:"92%",
                        width:"100%",
                        backgroundColor: weekBgColor}}>
            <Text style={{fontSize:14, fontWeight:weekFontWeight,color:weekFontColor}}>7 days</Text>
            </View>
        </TouchableOpacity>
        {/** 
        <TouchableOpacity style={{width:"25%", height:"100%"}} onPress={()=> props.onChange(Constants.ActivityDataFilters.month)}>
            <View style={{borderWidth:0,  
                        justifyContent:"center",
                        alignItems:"center",
                        margin:2,
                        padding:2,
                        borderRadius:8,
                        height:"92%",
                        width:"100%",
                        backgroundColor: monthBgColor}}>
            <Text style={{fontSize:14, fontWeight:monthFontWeight,color:monthFontColor}}>30 days</Text>
            </View>
        </TouchableOpacity>
        <TouchableOpacity style={{width:"25%", height:"100%"}} onPress={()=> props.onChange(Constants.ActivityDataFilters.year)}>
            <View style={{borderWidth:0,  
                        justifyContent:"center",
                        alignItems:"center",
                        margin:2,
                        marginLeft:0,
                        padding:2,
                        borderRadius:8,
                        height:"92%",
                        width:"100%",
                        backgroundColor: yearBgColor}}>
            <Text style={{fontSize:14, fontWeight:yearFontWeight,color:yearFontColor}}>365 days</Text>
            </View>
        </TouchableOpacity>*/}
        </View>);
};
