import React from 'react';
import {StyleSheet, View ,Dimensions} from 'react-native';
import { Svg, G, Line, Rect,Circle,Text,Path} from 'react-native-svg';
import * as d3 from 'd3';
import {Colors} from "../style/allstyles";
import {DateUtils} from "../utils/dateutils";

export class VitalsActivity24HrChart extends React.PureComponent{
    
    render(){
        console.log("VitalsActivity24HrChart:Into render...["+this.props.type+"]");
        let margin = 24;
        let w = Dimensions.get("window").width - margin;
        let h = 300;
        let data = this.props.chartData;
        let type = this.props.type;

        if( data == null || data["readings"] == null ) return <View></View>;
        let y = this.getDomainAndRangeY(data,type,h - 80);
        let x = this.getDomainAndRangeX(data,type,w - 24);
        let legendText = (type=="hr") ? "resting heart rate" : "respiratory rate";
        let maxY = this.getMaxY(data,type);
        let startEndTimeText = DateUtils.getStartEndTimeText( data["start"], data["end"] ); 
        console.log("startEndTimeText=" + startEndTimeText);
        return(
            <Svg width={w} height={h} style={{}}>
                <G transform='translate(0,0)'>
                    <Text x='95%' y={10} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{maxY}</Text>
                    <Line x1={0} y1={12} x2={w} y2={10} stroke={Colors.lightGray}></Line>
                    <Text x='95%' y={110} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{maxY/2}</Text>
                    <Line x1={0} y1={110} x2={w} y2={110} stroke={Colors.lightGray}></Line>

                    <Line x1={0} y1={h-70} x2={w} y2={h-70} stroke={Colors.lightGray}></Line>
                    <Text x='0%' y={h-50} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{startEndTimeText["st"]}</Text>
                    {/*<Text x='45%' y={h-50} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>9PM</Text>*/}
                    <Text x='90%' y={h-50} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{startEndTimeText["et"]}</Text>
                </G>
                <G transform='translate(0,12)'>
                    
                    <Path d={this.drawPath(data,type,x,y)} 
                            fill="transparent" 
                            strokeWidth={2}
                            stroke={Colors.vinyaDefaultColor}></Path>
                    {
                        this.getReadings(data,type,x,y).map((elm,idx)=>{
                            //console.log("(x,y)= (" + elm.x + "," + elm.y + ")");
                            if(elm.y != null)
                                return <Circle key={type + "_" + idx} cx={elm.x} cy={elm.y} r="4" stroke={Colors.vinyaDefaultColor} strokeWidth={2} fill="white" ></Circle>
                        })
                    }
                </G>
                {/*
                <G transform='translate(0,280)'>
                    <Line x1={0} y1={12} x2={60} y2={12} strokeWidth={2} stroke={Colors.vinyaDefaultColor}></Line>
                    <Text x={80} y={15} fontSize='12' fill={Colors.mediumGray}>
                        {legendText}
                    </Text>
                </G>*/}
            </Svg>
        );
    }
    getMaxY(data,sel){
        let readings = data["readings"];
        let maxY = Number.MIN_SAFE_INTEGER;
        for(let idx=0; idx < readings.length; idx++){
            let value = readings[idx][sel];
            if(value !=null){
                value = Math.ceil(value);
                if(value > maxY) maxY = value;
            }
        }
        console.log("Max Y=" + maxY);
        return maxY;
    }
    getReadings(data,sel,xd,yd){
        let readings = data["readings"];
        let points=[];
        for(let idx=0; idx < readings.length; idx++){
            let value = readings[idx][sel];
            if(value !=null){
                points.push({
                        x: xd(new Date(readings[idx]["time"]).getTime()),
                        y: yd(value)
                    });
            }
        }
        return points;
    }

    drawPath(data,sel,xd,yd){
        let readings = data["readings"];
        let cmd = "";
        let addedMoveCmd=false;
        for(let idx=0; idx < readings.length; idx++){
            let value = readings[idx][sel];
            let xval = 0;
            let yval=0;
            if(value != null){
                xval = new Date(readings[idx]["time"]).getTime();
                yval = readings[idx][sel];
                if(yval == null) yval=0;
                //console.log("(x,y) = (" + xval + "," + yval + ")" );
                if(!addedMoveCmd /**first time */) {
                    cmd = "M " ;
                    addedMoveCmd=true;
                }else
                    cmd += " L " ;
                
                cmd +=xd(xval) + " " + yd(yval) ; 
            }
        }
        //console.log("Path=" + cmd);
        return cmd;
    }

    getDomainAndRangeY(data, sel,h){
        let readings = data["readings"];
        let min = Number.MAX_SAFE_INTEGER;
        let max = Number.MIN_SAFE_INTEGER;
        for(let idx=0;idx < readings.length; idx++){
            let reading = readings[idx];
            let value = reading[sel];
            if(value !=null){
                if(value > max) max = value;
                if(value < min) min = value;
            }
        }
        //create the domain and range
        console.log("Domain Y==[" + min + "," + max +"]" );
        let y = d3.scaleLinear().domain([min,max]).range([0,h]);
        return y;
    }
    getDomainAndRangeX(data, sel /*future */,w){
        let readings = data["readings"];
        let min = new Date(9999,12,31).getTime();
        let max = new Date(1970,1,1).getTime();
        for(let idx=0;idx < readings.length; idx++){
            let reading = readings[idx];
            let recordDt = new Date(reading["time"]).getTime();
            if(recordDt > max) max = recordDt;
            if(recordDt < min) min = recordDt;
        }
        //create the domain and range
        console.log("Domain X==[" + min + "," + max +"]" );
        let x = d3.scaleLinear().domain([min,max]).range([0,w]);
        return x;
    }
}
