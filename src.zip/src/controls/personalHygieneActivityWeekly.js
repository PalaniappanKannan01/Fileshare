import React from 'react';
import {StyleSheet, View ,Dimensions} from 'react-native';
import { Svg, G, Line, Rect,XAxis,Text} from 'react-native-svg';
import * as d3 from 'd3';
import {Colors} from "../style/allstyles";
import {DateUtils} from "../utils/dateutils";

export class PersonalHygieneActivityWeeklyChart extends React.PureComponent{
    
    render(){
        console.log("PersonalHygieneActivityWeeklyChart:Into render...");
        let margin = 24;
        let w = Dimensions.get("window").width - margin;
        let bw = 14;
        let h = 140;
        let data = this.props.chartData;
        //console.log("data=" + (data.toiletEvents));
        if( data == null ) return <View></View>;
        let maxY = this.getMaxY(data);
        let ty = this.getYToiletDomain(maxY,h);
        let by = this.getYBathDomain(maxY,h);
        let x = this.getXDomain(data,w);
        let displayOrder = DateUtils.getDatesAsWeekdays(
            DateUtils.apiDateToJSDate(data["start"]),
            DateUtils.apiDateToJSDate(data["end"])
        );
        return(
            <Svg width={w} height={300} style={{}}>
                <G transform="translate(0,100)">
                    <Line key={"100"} x1={20} y1={0} x2={w} y2={0} stroke={Colors.lightGray}></Line>
                    <Text key={"200"} x='0' y={0} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{maxY}</Text>
                    <Line key={"300"} x1={20} y1={h/2} x2={w} y2={h/2} stroke={Colors.lightGray}></Line>
                    <Text key={"400"} x='0' y={h/2} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{Math.ceil(maxY/2)}</Text>
                    <Line key={"500"} x1={20} y1={h} x2={w} y2={h} stroke={Colors.lightGray}></Line>
                    <Text key={"600"} x='0' y={h} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{0}</Text>
                </G>
                <G transform="translate(0,100)">
                    {
                        displayOrder.map((wd,idx)=>{
                            return(
                            <G Key={"g_"+idx}>
                                <Text key={"wd_"+idx} x={20 + (idx*50)} y={h + 20} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{wd.substring(0,3)}</Text>
                                
                                <Rect key={"wdT"+idx} x={20 + (idx*50)} y={h - this.getYPosForEvent(data,wd,ty, "toiletEvents",maxY) } width={bw} 
                                        height={ this.getYPosForEvent(data,wd,ty, "toiletEvents",maxY) } fill={Colors.vinyaDefaultColor}></Rect>
                                <Rect key={"wdB"+idx} x={35 + (idx*50)} y={h - this.getYPosForEvent(data,wd,by, "bathEvents",maxY)} width={bw} 
                                        height={ this.getYPosForEvent(data,wd,by, "bathEvents",maxY) } fill={Colors.appRed}></Rect>
                            </G>
                            );
                        })
                    }
                </G>
                <G transform="translate(0,280)" style={{}}>
                    <Rect key={"700"} x={20} y={0} width={24}      
                        height={ 24 } fill={Colors.vinyaDefaultColor}></Rect>
                    <Text key={"800"} x={50} y={15} fontSize='12' fontWeight="bold" fill={Colors.mediumGray}>Toileting</Text>

                    <Rect key={"900"} x={120} y={0} width={24}      
                        height={ 24 } fill={Colors.appRed}></Rect>
                    <Text key={"1000"} x={150} y={15} fontSize='12' fontWeight="bold" fill={Colors.mediumGray}>Bathing</Text>
                </G>
            </Svg>
        );
    }
    getEventCountForWeekday(data,wd,evt){
        let days = data["days"];
        for(let idx=0; idx < days.length; idx++){
            let day = days[idx];
            if(day["dayName"]==wd){
                return day[evt];
            }
        }
        return 0;
    }
    getToiletVisitsOnDoW(json, dow, y){
        let days = json["days"];
        for(let idx=0; idx < days.length; idx++){
            if(days[idx]["dayLabel"] == dow){
                let t = days[idx]["toiletEvents"];
                console.log("Toilets on " + dow + " =" + t + ", range=" + y(t));
                return t;
            }
        }
        return 0;
    }
    getBathsOnDoW(json, dow){
        let days = json["days"];
        for(let idx=0; idx < days.length; idx++){
            if(days[idx]["dayLabel"] == dow){
                let b = days[idx]["bathEvents"];
                console.log("Baths on " + dow + " =" + b);
                return b;
            }
        }
        return 0;
    }
    
    getYPosForEvent(data,wd,yd, evtype,maxY){
        let eventCount = this.getEventCountForWeekday(data,wd, evtype);
        let ypos = yd(eventCount);
        console.log("Event Type=" + evtype + ", eventCount=" + eventCount + ", ypos=" + ypos);
        return ypos;
    }
    getXDomain(json,w){
        let startdt = new Date(json["start"]).getTime();
        let enddt = new Date(json["end"]).getTime();

        let x = d3.scaleLinear().domain([startdt , enddt]).range([0,w - 24]);
        return x;
    }

    getYToiletDomain(maxy,h){
        /*
        let days = json["days"];
        let min = Number.MAX_SAFE_INTEGER;
        let max = Number.MIN_SAFE_INTEGER;
        for(let idx=0; idx < days.length; idx++){
            let te = days[idx]["toiletEvents"];
            if(te > max) max = te;
            if(te < min) min = te;
        }*/
        let ty = d3.scaleLinear().domain([0,maxy]).range([0,h]);
        return ty;
    }
    getYBathDomain(maxy,h){
        let ty = d3.scaleLinear().domain([0,maxy]).range([0,h]);
        return ty;
    }

    getMaxY(json){
        let days = json["days"];
        let max = Number.MIN_SAFE_INTEGER;
        for(let idx=0; idx < days.length; idx++){
            let be = days[idx]["bathEvents"];
            let te = days[idx]["toiletEvents"];
            let compare = be > te ? be : te;

            if(compare > max) max = compare;
        }
        console.log("Max Y value=" + max);
        return max;
    }

    
}
