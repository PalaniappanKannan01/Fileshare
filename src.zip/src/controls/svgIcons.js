/*
    SVG renderings as JSX...
    See https://react-svgr.com/playground/?native=true
 */
import * as React from "react";
import Svg, { Mask, Path, G ,Circle , Defs , ClipPath} from "react-native-svg"
import {Colors} from "../style/allstyles";

export const VIDALogo = (props) =>{
  return (
    <Svg width={props.width} height={props.height} viewBox="0 0 87 86" fill="none" >
      <Path
        d="M84.827 28.233c6.157 17.488-1.732 41.172-16.739 51.304-15.006 10.132-37.196 6.776-51.305-4.324C2.738 64.049-3.227 45.205 1.712 29.394 6.65 13.584 22.49.741 40.512.031c18.021-.71 38.158 10.713 44.315 28.202z"
        fill="#9775FA"
      />
      <Path
        d="M45.917 16.022c.025-3.02 4.204-3.653 5.184-.91l.064.203 7.027 24.802h4.665a2.676 2.676 0 012.668 2.475l.007.2a2.675 2.675 0 01-2.475 2.667l-.2.008H56.17a2.674 2.674 0 01-2.508-1.747l-.065-.2-2.696-9.512-.094 2.454c-1.01 24.226-3.723 35.471-9.571 35.747l-.223.005c-5.604 0-8.725-7.94-10.97-24.34l-.317-2.407H25.41a2.675 2.675 0 01-2.667-2.476l-.008-.2a2.675 2.675 0 012.476-2.667l.2-.007h6.686c1.357 0 2.5 1.017 2.657 2.365 1.02 8.75 2.253 15.275 3.67 19.525.944 2.831 1.837 4.285 2.328 4.717l.069.057.015-.017c.22-.27.473-.708.736-1.311l.113-.268c.77-1.887 1.465-4.824 2.05-8.764l.09-.63c1.244-8.775 1.944-22.046 2.092-39.77z"
        fill="#fff"
      />
    </Svg>
  )
};

export const HomeWithLamp = (props) =>{
    return(<Svg width={335} height={181} viewBox="0 0 335 181" fill="none" {...props}>
    <G clipPath="url(#prefix__clip0)">
      <Mask
        id="prefix__a"
        maskUnits="userSpaceOnUse"
        x={1}
        y={0}
        width={334}
        height={181}
      >
        <Path
          d="M276.079 1.03c54.038 6.204 70.762 66.154 50.173 179.85H2.572c-4.249-36.059.554-60.503 14.41-73.33 49.437-45.373 95.147-17.75 130.706-33.963 43.831-20.163 47.471-82.002 128.391-72.558z"
          fill="#fff"
        />
      </Mask>
      <G mask="url(#prefix__a)">
        <Path
          d="M276.079 1.03c54.038 6.204 70.762 66.154 50.173 179.85H2.572c-4.249-36.059.554-60.503 14.41-73.33 49.437-45.373 95.147-17.75 130.706-33.963 43.831-20.163 47.471-82.002 128.391-72.558z"
          fill="#F5F8FF"
        />
        <Path
          d="M153.091-46.313h188.084a5.403 5.403 0 015.403 5.403v188.084a5.403 5.403 0 01-5.403 5.403H153.091a5.403 5.403 0 01-5.403-5.403V-40.91a5.403 5.403 0 015.403-5.403z"
          fill="#fff"
        />
        <Mask
          id="prefix__b"
          maskUnits="userSpaceOnUse"
          x={152}
          y={-42}
          width={190}
          height={190}
        >
          <Path
            d="M341.432-41.167H152.834V147.43h188.598V-41.167z"
            fill="#fff"
          />
        </Mask>
        <G mask="url(#prefix__b)">
          <Path
            d="M341.432-41.167H152.834V147.43h188.598V-41.167z"
            fill="#DBE4FF"
          />
          <Path
            d="M348.122 95.972h-90.054v124.017h90.054V95.972zM258.068 67.154h-70.499v124.017h70.499V67.155zM187.569 117.842H117.07v124.017h70.499V117.842z"
            fill="#BAC8FF"
          />
          <Path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M244.691 46.979h119.481s3.238-12.915-19.449-8.61c-22.686 4.305-19.135-7.84-32.713-10.645-13.577-2.804-20.085 8.623-40.783 2.804-20.698-5.818-35.916 16.45-26.536 16.45z"
            fill="#F5F8FF"
          />
          <Path
            d="M252.655 36.73a1.287 1.287 0 01-2.038 1.572c-3.156-4.093-6.553-4.093-10.954.141a1.286 1.286 0 01-1.804-.02c-4.188-4.215-7.588-4.215-10.956-.093a1.287 1.287 0 01-1.993-1.628c4.123-5.046 8.961-5.334 13.879-.942 5.112-4.394 9.948-4.11 13.866.97zM280.957 54.741a1.286 1.286 0 11-2.037 1.571c-3.156-4.092-6.554-4.092-10.954.142a1.287 1.287 0 01-1.805-.02c-4.187-4.215-7.587-4.215-10.956-.093a1.286 1.286 0 11-1.992-1.628c4.123-5.046 8.96-5.334 13.879-.942 5.111-4.394 9.947-4.11 13.865.97z"
            fill="#BAC8FF"
          />
          <Path
            d="M206.866-33.449h-5.146v180.88h5.146v-180.88zM292.546-33.449H287.4v180.88h5.146v-180.88z"
            fill="#fff"
          />
          <Path
            d="M341.432 80.534H152.834v5.146h188.598v-5.146zM341.432 13.637H152.834v5.146h188.598v-5.146z"
            fill="#fff"
          />
        </G>
      </G>
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M3.86 173.161h321.105a3.859 3.859 0 110 7.718H3.859a3.86 3.86 0 110-7.718z"
        fill="#DBE4FF"
      />
      <Path d="M80.791 56.862h-5.146v116.299h5.146V56.862z" fill="#DBE4FF" />
      <Mask
        id="prefix__c"
        maskUnits="userSpaceOnUse"
        x={55}
        y={0}
        width={46}
        height={57}
      >
        <Path
          d="M66.255 0h23.926c.373 0 .693.267.76.634l10.012 55.32a.772.772 0 01-.76.908h-43.95a.772.772 0 01-.76-.909L65.496.634a.772.772 0 01.76-.634z"
          fill="#fff"
        />
      </Mask>
      <G mask="url(#prefix__c)">
        <Path
          d="M66.255 0h23.926c.373 0 .693.267.76.634l10.012 55.32a.772.772 0 01-.76.908h-43.95a.772.772 0 01-.76-.909L65.496.634a.772.772 0 01.76-.634z"
          fill="#DBE4FF"
        />
        <Path
          d="M100.346 40.138H55.061v6.433h45.285v-6.433z"
          fill="#F5F8FF"
        />
      </G>
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M48.648 155.922c-4.45-12.738-22.085-8.861-24.169-17.993-1.998-9.231 7.466-9.872 7.437-17.062.03-7.191-19.354-5.682-21.309-13.03-1.919-7.341 5.148-9.025 12.728-11.633C31.02 93.707 6.62 80.548 8.891 67.354 11.18 54.197 29.95 54.28 33.203 70.61c3.375 16.306 6.404 21.352 11.012 14.735 4.574-6.553 17.33-4.179 11.87 14.58-5.427 18.854 10.344 12.954 12.727 25.129 2.243 12.312-14.909 16.031-20.164 30.867z"
        fill="#BAC8FF"
      />
      <Path
        d="M63.832 86.59c.552 5.89-.127 12.26-1.895 19.577-.517-3.485-1.951-6.05-4.302-7.696-4.28-2.996-9.199-3.354-10.988-.799-1.79 2.556.229 7.056 4.508 10.052 2.665 1.866 6.036 2.221 10.114 1.065-1.11 4.172-2.471 8.39-4.79 15.128l-.087.252c-.475-3.649-1.924-6.322-4.347-8.019-4.279-2.996-9.198-3.354-10.988-.798-1.789 2.555.23 7.056 4.508 10.052 2.646 1.853 5.99 2.216 10.029 1.089-2.736 7.985-3.885 11.558-4.82 15.332-.623-3.011-2.001-5.264-4.136-6.759-4.28-2.996-9.198-3.353-10.988-.798-1.789 2.556.23 7.056 4.508 10.052 2.593 1.815 5.855 2.201 9.785 1.156-1.347 6.583-1.462 12.057-.147 16.89a.643.643 0 101.241-.338c-1.335-4.909-1.123-10.577.435-17.547 1.167-5.219 2.229-8.539 6.223-20.145 2.662-7.736 4.07-12.171 5.286-17.029 2.212-8.834 2.904-16.348 1.824-23.316a.64.64 0 00-.23-.4c-.559-3.312-1.975-5.763-4.248-7.355-4.28-2.996-9.198-3.354-10.988-.798-1.789 2.555.23 7.055 4.508 10.052 2.636 1.846 5.965 2.213 9.985 1.1z"
        fill="#DBE4FF"
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M34.22 149.489h27.274c.426 0 .772.346.772.772v22.9H33.449v-22.9c0-.426.345-.772.771-.772z"
        fill="#DBE4FF"
      />
    </G>
    <Defs>
      <ClipPath id="prefix__clip0">
        <Path fill="#fff" d="M0 0h335v180.879H0z" />
      </ClipPath>
    </Defs>
  </Svg>);
};

export const GreenTick = (props)=>{
    return (
        <Svg width={props.width} height={props.height} viewBox="0 0 58 58" fill="none" {...props}>
          <Path
            d="M55.667 26.547V29A26.667 26.667 0 1139.853 4.627"
            stroke="#52C883"
            strokeWidth={4}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <Path
            d="M55.667 7.667L29 34.36l-8-8"
            stroke="#52C883"
            strokeWidth={4}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </Svg>
      );
};

export const SleepIcon = (props)=>{
    return (
        <Svg width={48} height={48} viewBox="0 0 46 36" fill="none" {...props}>
          <Path
            d="M1 35V1M45 35V21M1 29h44M1 21h44M10 16a4 4 0 100-8 4 4 0 000 8zM19 9h22a4 4 0 014 4v3H19V9z"
            stroke="#868E96"
            strokeWidth={2}
            strokeMiterlimit={10}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </Svg>
      );
};

export const MobilityIcon = (props) =>{
    return(<Svg width={48} height={48} viewBox="0 0 26 46" fill="none" {...props}>
    <Path
      d="M12.7998 16.1L19.9998 22L24.9998 20"
      stroke="#868E96"
      strokeWidth={2}
      strokeMiterlimit={10}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <Path
      d="M7 17L3 19L1 24"
      stroke="#868E96"
      strokeWidth={2}
      strokeMiterlimit={10}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <Path
      d="M15 30L19 34V43"
      stroke="#868E96"
      strokeWidth={2}
      strokeMiterlimit={10}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <Path
      d="M15 11C17.7614 11 20 8.76142 20 6C20 3.23858 17.7614 1 15 1C12.2386 1 10 3.23858 10 6C10 8.76142 12.2386 11 15 11Z"
      stroke="#868E96"
      strokeWidth={2}
      strokeMiterlimit={10}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <Path
      d="M6 45L14.022 10.904"
      stroke="#868E96"
      strokeWidth={2}
      strokeMiterlimit={10}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </Svg>);
};

export const VitalsIcon = (props) =>{
    return(<Svg width={48} height={48} viewBox="0 0 46 44" fill="none" {...props}>
    <Path
      d="M1 21H14L19 14L27 28L32 21H45"
      stroke="#868E96"
      strokeWidth={2}
      strokeMiterlimit={10}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <Path
      d="M43.822 15C43.9374 14.3395 43.9969 13.6705 44 13C44 6.4 38.845 1 32.545 1C30.6228 0.99757 28.7329 1.49385 27.0599 2.44034C25.3868 3.38683 23.988 4.75116 23 6.4C22.012 4.75116 20.6132 3.38683 18.9401 2.44034C17.2671 1.49385 15.3772 0.99757 13.455 1C7.155 1 2 6.4 2 13C2.00308 13.6705 2.06263 14.3395 2.178 15"
      stroke="#868E96"
      strokeWidth={2}
      strokeMiterlimit={10}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <Path
      d="M8.0791 27C12.5032 32.8206 17.5021 38.1809 23.0001 43C28.4981 38.1809 33.497 32.8206 37.9211 27"
      stroke="#868E96"
      strokeWidth={2}
      strokeMiterlimit={10}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </Svg>);
};

export const PersonalHygieneIcon = (props) =>{
    return(<Svg width={48} height={48} viewBox="0 0 44 46" fill="none" {...props}>
    <Path
      d="M10 41v4M34 41v4M1 27v8a6 6 0 006 6h30a6 6 0 006-6v-8H1zM28 15H16a6.018 6.018 0 016-6v0a6.018 6.018 0 016 6v0z"
      stroke="#868E96"
      strokeWidth={2}
      strokeMiterlimit={10}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <Path
      d="M22 9V7a6 6 0 016-6v0a6 6 0 016 6v15"
      stroke="#868E96"
      strokeWidth={2}
      strokeMiterlimit={10}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <Path
      d="M18 20a1 1 0 100-2 1 1 0 000 2zM22 23a1 1 0 100-2 1 1 0 000 2zM26 20a1 1 0 100-2 1 1 0 000 2z"
      fill="#868E96"
    />
  </Svg>
    );
};

export const NutritionIcon = (props) =>{
    return (
        <Svg width={48} height={48} viewBox="0 0 42 42" fill="none" {...props}>
          <Path
            d="M35 19H7v16h28V19zM28 25H14"
            stroke="#868E96"
            strokeWidth={2}
            strokeMiterlimit={10}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <Path
            d="M26 8a1 1 0 100-2 1 1 0 000 2zM34 8a1 1 0 100-2 1 1 0 000 2z"
            fill="#868E96"
          />
          <Path
            d="M38 1H4a3 3 0 00-3 3v34a3 3 0 003 3h34a3 3 0 003-3V4a3 3 0 00-3-3zM7 7h6M1 13h40"
            stroke="#868E96"
            strokeWidth={2}
            strokeMiterlimit={10}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </Svg>
      );
};

export const StatusIcon = (props)=>{
    let statusId = props.statusId;
    //console.log("Into StatusIcon->statusId=" + statusId);

    if(statusId == 1){
        return (
            <Svg width={34} height={34} viewBox="0 0 34 34" fill="none" {...props}>
                <Circle
                cx={17}
                cy={17}
                r={16}
                fill="#E6FCF5"
                stroke="#38D9A9"
                strokeWidth={2}
                />
                <Path
                d="M26 12L15 23L10 18"
                stroke="#12B886"
                strokeWidth={2.5}
                strokeLinecap="round"
                strokeLinejoin="bevel"
                />
            </Svg>
          );
    }else if(statusId == 2){
        return (
            <Svg width={34} height={34} viewBox="0 0 34 34" fill="none" {...props}>
                <Circle
                cx={17}
                cy={17}
                r={16}
                fill="#FFF5F5"
                stroke="#FF6B6B"
                strokeWidth={2}
                />
                <Path
                d="M17 11V17"
                stroke="#FA5252"
                strokeWidth={3}
                strokeLinecap="round"
                strokeLinejoin="round"
                />
                <Path
                d="M17 23H17.01"
                stroke="#FA5252"
                strokeWidth={4}
                strokeLinecap="round"
                strokeLinejoin="round"
                />
            </Svg>
          );
    }else if(statusId == 3){
        return (
            <Svg viewBox="0 0 34 34" fill="none" {...props}>
              <Circle
                cx={17}
                cy={17}
                r={16}
                fill="#FFF4E6"
                stroke="#FFA94D"
                strokeWidth={2}
              />
              <Path
                d="M17 11v6"
                stroke="#FD7E14"
                strokeWidth={3}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <Path
                d="M17 23h.01"
                stroke="#FD7E14"
                strokeWidth={4}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </Svg>
          );
    }else{
        return (
            <Svg viewBox="0 0 34 34" fill="none" {...props}>
              <Circle
                cx={17}
                cy={17}
                r={16}
                fill="#F8F9FA"
                stroke="#DEE2E6"
                strokeWidth={2}
              />
              <Path
                d="M17 25.333a8.333 8.333 0 100-16.666 8.333 8.333 0 000 16.666zM11.108 11.108l11.784 11.784"
                stroke="#868E96"
                strokeWidth={2}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </Svg>
          );
    }
};

export const SummaryIcon = (props)=>{
    let strokeColor="#868E96";
    if(props.focus){
        strokeColor=Colors.vinyaDefaultColor;
    }
    return (
        <Svg width={14} height={18} viewBox="0 0 14 18" fill="none" {...props}>
          <Path
            d="M13 17V1M7 17v-6 6zm-6 0V7v10z"
        stroke={strokeColor}
            strokeWidth={2}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </Svg>
      );
};

export const NotificationIcon = (props)=>{
    let strokeColor="#868E96";
    if(props.focus){
        strokeColor=Colors.vinyaDefaultColor;
    }
    return (
        <Svg width={23} height={21} viewBox="0 0 23 21" fill="none" {...props}>
      <Path
        d="M18 11V8A7 7 0 104 8v3c0 3.3-3 4.1-3 6 0 1.7 3.9 3 10 3s10-1.3 10-3c0-1.9-3-2.7-3-6z"
        stroke={strokeColor}
        strokeWidth={2}
        strokeMiterlimit={10}
        strokeLinecap="square"
      />
      <Circle
        cx={17}
        cy={5}
        r={5}
        fill={strokeColor}
        stroke="#fff"
        strokeWidth={2}
      />
    </Svg>
      );
};

export const SettingsIcon = (props)=>{
    let strokeColor="#868E96";
    if(props.focus){
        strokeColor=Colors.vinyaDefaultColor;
    }
    return (
        <Svg width={24} height={24} viewBox="0 0 24 24" fill="none" {...props}>
          <Path
            d="M12 15a3 3 0 100-6 3 3 0 000 6z"
            stroke={strokeColor}
            strokeWidth={2}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <Path
            d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a1.998 1.998 0 010 2.83 1.998 1.998 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a1.998 1.998 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 114 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 013.417 1.415 2 2 0 01-.587 1.415l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1v0z"
            stroke={strokeColor}
            strokeWidth={2}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </Svg>
      );
};

export const InfoIcon = (props)=>{
    return (
        <Svg width={20} height={20} viewBox="0 0 20 20" fill="none" {...props}>
          <Path
            d="M10 18.333a8.333 8.333 0 100-16.666 8.333 8.333 0 000 16.666zM10 13.333V10M10 6.667h.008"
            stroke="#868E96"
            strokeWidth={1.5}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </Svg>
      );
};

export const SilentBellIcon = (props)=>{
    return (
        <Svg width={20} height={20} viewBox="0 0 20 20" fill="none" {...props}>
          <Path
            d="M15.833 9.167v-2.5a5.833 5.833 0 00-11.666 0v2.5c0 2.75-2.5 3.416-2.5 5 0 1.416 3.25 2.5 8.333 2.5s8.333-1.084 8.333-2.5c0-1.584-2.5-2.25-2.5-5z"
            stroke="#868E96"
            strokeWidth={1.5}
            strokeMiterlimit={10}
            strokeLinecap="square"
          />
          <Path
            d="M10 18.333c-.843 0-1.634-.028-2.38-.083a2.493 2.493 0 004.759 0 32.34 32.34 0 01-2.38.083z"
            fill="#868E96"
          />
        </Svg>
      );
};

export const PermissionIcon = (props) =>{
    return (
        <Svg width={20} height={20} viewBox="0 0 18 20" fill="none" {...props}>
          <Path
            d="M14.833 9.167H3.167c-.92 0-1.667.746-1.667 1.666v5.834c0 .92.746 1.666 1.667 1.666h11.666c.92 0 1.667-.746 1.667-1.666v-5.834c0-.92-.746-1.666-1.667-1.666zM4.833 9.167V5.833a4.167 4.167 0 118.334 0v3.334"
            stroke="#868E96"
            strokeWidth={1.5}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </Svg>
      );
};

export const HelpIcon = (props)=>{
    return (
        <Svg width={20} height={20} viewBox="0 0 20 20" fill="none" {...props}>
          <Path
            d="M10 18.333a8.333 8.333 0 100-16.666 8.333 8.333 0 000 16.666z"
            stroke="#868E96"
            strokeWidth={1.5}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <Path
            d="M7.575 7.5a2.5 2.5 0 014.859.833c0 1.667-2.5 2.5-2.5 2.5M10 14.167h.008"
            stroke="#868E96"
            strokeWidth={1.5}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </Svg>
      );
};

export const PhoneIcon = (props)=>{
    return (
        <Svg width={20} height={20} viewBox="0 0 22 22" fill="none" {...props}>
          <Path
            d="M21 15.92v3a1.999 1.999 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 013.11 1h3a2 2 0 012 1.72c.127.96.362 1.903.7 2.81a2 2 0 01-.45 2.11L7.09 8.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.908.339 1.85.573 2.81.7A2 2 0 0121 15.92z"
            stroke="#fff"
            strokeWidth={1.5}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </Svg>
      );
};

export const CameraIcon = (props)=>{
  return (
    <Svg width={22} height={20} viewBox="0 0 22 20" fill="none" {...props}>
      <Path
        d="M21 17a2 2 0 01-2 2H3a2 2 0 01-2-2V6c0-1.1.9-2 2-2h3l2-3h6l2 3h3a2 2 0 012 2v11z"
        stroke="#868E96"
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M11 15a4 4 0 100-8 4 4 0 000 8z"
        stroke="#868E96"
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  );
};

export const AvatarIcon = (props)=>{
  return (
    <Svg width={72} height={72} viewBox="0 0 104 104" fill="none" {...props}>
      <Path
        d="M19.598 87c3.2-11 9.2-15 16.1-15h32.6c6.9 0 12.9 4 16.1 15M52 57c8.284 0 15-6.716 15-15 0-8.284-6.716-15-15-15-8.284 0-15 6.716-15 15 0 8.284 6.716 15 15 15z"
        stroke="#868E96"
        strokeWidth={2.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M52 102c27.614 0 50-22.386 50-50S79.614 2 52 2 2 24.386 2 52s22.386 50 50 50z"
        stroke="#868E96"
        strokeWidth={2.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  );
};