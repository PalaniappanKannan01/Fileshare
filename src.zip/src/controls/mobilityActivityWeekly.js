import React from 'react';
import {StyleSheet, View ,Dimensions} from 'react-native';
import { Svg, G, Line, Rect,XAxis,Text} from 'react-native-svg';
import * as d3 from 'd3';
import {Colors} from "../style/allstyles";
import {DateUtils} from "../utils/dateutils";

export class MobilityActivityWeeklyChart extends React.PureComponent{
    
    render(){
        console.log("MobilityActivityWeeklyChart:Into render...");
        let margin = 24;
        let w = Dimensions.get("window").width - margin;
        let h = 240;
        let bw = 32;
        let gu = 10;
        let data = this.props.chartData;

        if( data == null || data["days"] == null ) return <View></View>;
        
        let x = this.getDomainAndRange(data,h);
        let maxY = this.getMaxValueAsCeiling(data);
        let midY = maxY/2;
        let displayOrder = DateUtils.getDatesAsWeekdays(
            DateUtils.apiDateToJSDate(data["start"]),
            DateUtils.apiDateToJSDate(data["end"])
        );

        return(
            <Svg width={w} height={w}>
                <G transform='translate(0,12)'>
                    <Text x='0' y={0} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{maxY}h</Text>
                    <Line x1={0} y1={0} x2={w} y2={0} stroke={Colors.lightGray}></Line>
                    <Text x='0' y={h/2} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>{midY}h</Text>
                    <Line x1={0} y1={h/2} x2={w} y2={h/2} stroke={Colors.lightGray}></Line>
                    <Text x='0' y={h} fontSize='14' fontWeight="normal" fill={Colors.mediumGray}>0h</Text>
                    <Line x1={0} y1={h} x2={w} y2={h} stroke={Colors.lightGray}></Line>
                    {
                        displayOrder.map((wd,idx)=>{
                            return (
                                <G key={"g_"+idx}>
                                    <Rect key={"wdb_" + idx} x={(1+idx)*bw + (idx*gu)} width={bw} y={h} height={-this.getDayDuration(data,wd,x)} fill={Colors.vinyaDefaultColor}/>
                                    <Text key={"wdt_" + idx} x={(1+idx)*bw + (idx*gu + 6)} y={h+20} fontSize='12' fontWeight="normal" fill={Colors.mediumGray}>{wd.substring(0,3)}</Text>
                                </G>
                            );
                        })
                    }
                </G>
            </Svg>
        );
    }
    
    getDomainAndRange(data,height){
        //iterate through each day and find the min and max value...
        let days = data["days"];
        let min = Number.MAX_SAFE_INTEGER;
        let max = Number.MIN_SAFE_INTEGER;
        for(let i=0; i < days.length; i++){
            let day = days[i];
            if(day["totalDuration"]["value"] > max) max = day["totalDuration"]["value"];
            if(day["totalDuration"]["value"] < min) min = day["totalDuration"]["value"];
        }
        console.log("Min-Max::[" + min + "," + max + "]");
        let x = d3.scaleLinear().domain([min,max]).range([0,height]);
        return x;
    }
    getMaxValueAsCeiling(data){
        //iterate through each day and find the min and max value...
        let days = data["days"];
        let max = Number.MIN_SAFE_INTEGER;
        for(let i=0; i < days.length; i++){
            let day = days[i];
            if(day["totalDuration"]["value"] > max) max = day["totalDuration"]["value"];
        }
        let maxY = Math.ceil(max);
        console.log("Maximum Y = " + maxY)
        return maxY;
    }
    getDayDuration(data,dayName,dr){
        //iterate through each day and find the min and max value...
        let days = data["days"];
        let duration = dr(0.00);
        
        for(let i=0; i < days.length; i++){
            let day = days[i];
            if(day["dayName"]== dayName){
                duration = dr(day["totalDuration"]["value"]);
                console.log(dayName + "=[" + day["totalDuration"]["value"] + " -> " + duration + "]");
            }
        }
        return duration;
    }
}
