import React from 'react';
import {StyleSheet, View ,Dimensions} from 'react-native';
import { Svg, G, Line, Rect,XAxis,Text} from 'react-native-svg';
import * as d3 from 'd3';
import {Colors} from "../style/allstyles";
import {DateUtils} from "../utils/dateutils";

export class PersonalHygieneActivity24HrChart extends React.PureComponent{
    
    render(){
        
        console.log("PersonalHygieneActivity24HrChart:Into render...");
        let margin = 24;
        let w = Dimensions.get("window").width - margin;
        let bh = 32;
        let data = this.props.chartData;
        //console.log("data=" + (data.toiletEvents));
        if( data == null || data["start"]==null) return <View></View>;

        let toiletVisits = this.getToiletVisits(data);
        let bathEvents = this.getBathEvents(data);
        let bathDuration= this.getTotalBathDurationText(bathEvents);
        let x = this.getXDomain(data,w);
        //console.log("data=" + JSON.stringify(data));
        let startEndTimeText = DateUtils.getStartEndTimeText( data["start"], data["end"] ); 
        console.log("startEndTimeText=" + startEndTimeText);
        return(
            <Svg width={w} height={300} style={{}}>
                <G transform='translate(0,90)'>
                    <Text key="x1" x='0' y={5} fontSize='14' fontWeight="bold" fill={Colors.black}>Toilet visits</Text>
                    <Text key="x2" x='65%' y={5} fontSize='14' fontWeight="normal" fill={Colors.black}>{toiletVisits.length} times</Text>
                </G>
                <G transform="translate(0,110)">
                    <Rect x={0} y={0} width={w} height={bh} fill={Colors.superLightGray} />
                    {/**Toilet event markers */}
                    {
                        toiletVisits.map((elm,idx)=>{
                            let xpos = this.getXPos(elm,x);
                            //console.log("XPos=" + elm + " , " + xpos);
                            return <Rect key={"tv_"+idx} x={xpos} y={0} width={1} height={bh} fill={Colors.vinyaDefaultColor}></Rect>;
                        })
                    }
                    
                    <Text x='0%' y={50} fontSize='12' fontWeight="normal" fill={Colors.lightGray}>{startEndTimeText["st"]}</Text>
                    {/*<Text x='30%' y={50} fontSize='12' fontWeight="normal" fill={Colors.lightGray}>6PM</Text>
                    <Text x='60%' y={50} fontSize='12' fontWeight="normal" fill={Colors.lightGray}>6AM</Text>*/}
                    <Text x='90%' y={50} fontSize='12' fontWeight="normal" fill={Colors.lightGray}>{startEndTimeText["et"]}</Text>
                </G>
                <G transform='translate(0,180)'>
                    <Text x='0' fontSize='14' fontWeight="bold" fill={Colors.black}>Bath duration</Text>
                    <Text x='65%' fontSize='14' fontWeight="normal" fill={Colors.black}>{bathDuration}</Text>
                </G>
                <G transform="translate(0,190)">
                    <Rect x={0} y={0} width={w} height={bh} fill={Colors.superLightGray} />
                    
                    {/**Bath taken event marker */}
                    {
                        bathEvents.map((e,i)=>{
                            let bi = this.getBathBand(e,x);
                            return (<Rect key={"be_" + i} x={bi.s} y={0} width={bi.w} height={bh} fill={Colors.vinyaDefaultColor}></Rect>);
                        })
                    }
                    <Text x='0%' y={50} fontSize='12' fontWeight="normal" fill={Colors.lightGray}>{startEndTimeText["st"]}</Text>
                    {/*<Text x='50%' y={50} fontSize='12' fontWeight="normal" fill={Colors.lightGray}>10PM</Text>*/}
                    <Text x='92%' y={50} fontSize='12' fontWeight="normal" fill={Colors.lightGray}>{startEndTimeText["et"]}</Text>
                </G>
            </Svg>
        );
    }
    
    getToiletVisits(json){
        let events = []
        for( te in json.toiletEvents){
            let dstr = json["toiletEvents"][te];
            let dt = new Date(dstr);
            console.log("dstr=" + dstr + ", date=" + dt);
            events.push( dt );
        }
        //console.log("All toilet visits = " + events);
        return events;
    }
    getBathEvents(json){
        let events = [];
        for( be in json.bathEvents){
            let snap = json["bathEvents"][be];
            events.push( snap );
        }
        return events;
    }

    getTotalBathDurationText(bEvents){
        let totalDiff = 0;
        for(let idx=0; idx < bEvents.length; idx++){
            let event= bEvents[idx];
            totalDiff += (
                new Date(event["end"]).getTime() - new Date(event["start"]).getTime()
            );
        }
        let duration = DateUtils.numToDuration(totalDiff);
        let text = DateUtils.prettyDuration(duration);

        console.log("Bath duration = " + text);
        return text;
    }
    
    getXDomain(json,w){
        let startdt = new Date(json["start"]).getTime();
        let enddt = new Date(json["end"]).getTime();

        let x = d3.scaleLinear().domain([startdt , enddt]).range([0,w])
        return x;
    }

    getXPos(v , xd){
        //console.log("Into getXPos..." + v);
        let date = new Date(v).getTime();
        return xd(date);
    }

    getBathBand(bEvent,xd){
        let start = xd(new Date(bEvent["start"]).getTime());
        let end = xd(new Date(bEvent["end"]).getTime());
        console.log("Bath event =[" + start + "," + end + "]");
        return {s : start , w : (end - start)};
    }
}
